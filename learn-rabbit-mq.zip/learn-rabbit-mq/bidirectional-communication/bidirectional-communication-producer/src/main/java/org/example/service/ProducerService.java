package org.example.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
public class ProducerService {
    Logger logger = LoggerFactory.getLogger(ProducerService.class);
    private final String ORDER_EXCHANGE = "amq.topic";
    private final String ORDER_ROUTING_KEY = "order";
    private final String ORDER_REPLY_QUEUE = "order.reply";

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public String sendOrder() {
        rabbitTemplate.setReceiveTimeout(TimeUnit.SECONDS.toMillis(5));
        String order = String.format("Producer produce order %s", UUID.randomUUID().toString().substring(0, 4));
        Message message = MessageBuilder
                .withBody(order.getBytes())
                .setReplyTo(ORDER_REPLY_QUEUE)
                .build();
        String reply = (String) rabbitTemplate.convertSendAndReceive(ORDER_EXCHANGE, ORDER_ROUTING_KEY, message);
        logger.info("Send msg: {}, {}", message.getMessageProperties().getMessageId(), new String(message.getBody()));
        return reply;
    }

    @RabbitListener(queues = ORDER_REPLY_QUEUE)
    public void handleReply(Message message) {
        try {
            logger.info("Received reply: {}", new String(message.getBody()));
        } catch (Exception e) {
            logger.error("process replay failed.", e);
        }
    }
}
