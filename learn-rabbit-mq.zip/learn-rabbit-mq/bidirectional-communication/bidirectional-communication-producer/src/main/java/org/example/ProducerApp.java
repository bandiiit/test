package org.example;

import org.example.service.ProducerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Producer Application
 */
@SpringBootApplication
public class ProducerApp
{
    private static final Logger logger = LoggerFactory.getLogger(ProducerApp.class);
    public static void main( String[] args )
    {
        SpringApplication.run(ProducerApp.class, args);
    }

    @Bean
    public CommandLineRunner runner(ProducerService orderProducer) {
        return args -> {
            ScheduledExecutorService executorService = Executors.newScheduledThreadPool(2);

            Runnable task1 = () -> {
                String reply = orderProducer.sendOrder();
                logger.info("Main App Reply received: {}", reply);
            };

            Runnable task2 = () -> {
                String reply = orderProducer.sendOrder();
                logger.info("Main App Reply received: {}", reply);
            };

            executorService.scheduleAtFixedRate(task1, 0, 10, TimeUnit.SECONDS);
            executorService.scheduleAtFixedRate(task2, 0, 10, TimeUnit.SECONDS);

        };
    }
}
