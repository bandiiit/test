#!/bin/bash
set -e

# Start RabbitMQ server in the background
rabbitmq-server -detached

# Wait for RabbitMQ server to start
sleep 10

# Run the setup script
/usr/local/bin/rabbitmq-setup.sh

# Keep RabbitMQ server running in the foreground
rabbitmqctl await_startup
rabbitmqctl shutdown
rabbitmq-server
