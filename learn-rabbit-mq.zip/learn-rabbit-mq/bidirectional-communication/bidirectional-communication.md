1. start rabbitmq

> docker-compose up rabbitmq

2. start rabbit with init queue

> docker-compose build
> 
> docker-compose up