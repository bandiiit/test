# rabbitmq-setup.sh
#!/bin/bash

# Wait for RabbitMQ server to start
sleep 10

# Create the 'order' queue
/usr/local/bin/rabbitmqadmin --host=localhost --port=15672 --username=guest --password=guest declare queue name=order durable=true

# Create the 'order.reply' queue
/usr/local/bin/rabbitmqadmin --host=localhost --port=15672 --username=guest --password=guest declare queue name=order.reply durable=true

# Bind the 'amq.topic' exchange to 'order' queue with routing key 'order'
/usr/local/bin/rabbitmqadmin --host=localhost --port=15672 --username=guest --password=guest declare binding source="amq.topic" destination_type="queue" destination="order" routing_key="order"
