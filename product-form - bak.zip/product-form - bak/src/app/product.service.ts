import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

export interface Product {
  id: number;
  category: string;
  name: string;
  price: number;
  quantity: number;
  attributes: {
    ripenessLevel?: string;
    origin?: string;
    size?: string;
    type?: string;
    flavor?: string;
    volume?: string;
    packaging?: string;
    // ... any other specific attributes
  };
}

// Sample initial products for demonstration
// const INITIAL_PRODUCTS: Product[] = [
//   {
//     id: 1,
//     category: 'Fruit',
//     name: 'Banana',
//     price: 0.5,
//     quantity: 20,
//     ripenessLevel: 'Ripe',
//     origin: 'Ecuador',
//     // ... (additional properties specific to fruits)
//   },
//   {
//     id: 2,
//     category: 'Vegetables',
//     name: 'Carrot',
//     price: 0.3,
//     quantity: 34,
//     size: 'Medium',
//     type: 'Nantes',
//     // ... (additional properties specific to vegetables)
//   },
//   {
//     id: 3,
//     category: 'Beverage',
//     name: 'Coke',
//     price: 1.0,
//     quantity: 15,
//     flavor: 'Classic',
//     volume: '12 oz',
//     // ... (additional properties specific to beverages)
//   },
//   {
//     id: 4,
//     category: 'Baking Ingredient',
//     name: 'All-Purpose Flour',
//     price: 0.2,
//     quantity: 25,
//     packaging: '2 lb bag',
//     // ... (additional properties specific to baking ingredients)
//   },
//   {
//     id: 5,
//     category: 'Fruit',
//     name: 'Apple',
//     price: 0.7,
//     quantity: 55,
//     ripenessLevel: 'Fresh',
//     origin: 'USA',
//     // ... (additional properties specific to fruits)
//   },
//   {
//     id: 6,
//     category: 'Vegetables',
//     name: 'Potato',
//     price: 0.4,
//     quantity: 80,
//     size: 'Large',
//     type: 'Russet',
//     // ... (additional properties specific to vegetables)
//   },
//   //... (feel free to add more sample products across different categories)
// ];

// Sample initial products for demonstration
const INITIAL_PRODUCTS: Product[] = [
  {
    id: 1,
    category: 'Fruit',
    name: 'Banana',
    price: 0.5,
    quantity: 20,
    attributes: {
      ripenessLevel: 'Ripe',
      origin: 'Ecuador',
      // ... additional attributes specific to "Fruit" category if any
    }
  },
  {
    id: 2,
    category: 'Vegetables',
    name: 'Carrot',
    price: 0.3,
    quantity: 34,
    attributes: {
      size: 'Medium',
      type: 'Nantes',
      // ... additional attributes specific to "Vegetables" category if any
    }
  },
  {
    id: 3,
    category: 'Beverage',
    name: 'Coke',
    price: 1.0,
    quantity: 15,
    attributes: {
      flavor: 'Classic',
      volume: '12 oz',
      // ... additional attributes specific to "Beverage" category if any
    }
  },
  {
    id: 4,
    category: 'Baking Ingredient',
    name: 'All-Purpose Flour',
    price: 0.2,
    quantity: 25,
    attributes: {
      packaging: '2 lb bag',
      // ... additional attributes specific to "Baking Ingredient" category if any
    }
  },
  {
    id: 5,
    category: 'Fruit',
    name: 'Apple',
    price: 0.7,
    quantity: 55,
    attributes: {
      ripenessLevel: 'Fresh',
      origin: 'USA',
      // ... additional attributes specific to "Fruit" category if any
    }
  },
  {
    id: 6,
    category: 'Vegetables',
    name: 'Potato',
    price: 0.4,
    quantity: 80,
    attributes: {
      size: 'Large',
      type: 'Russet',
      // ... additional attributes specific to "Vegetables" category if any
    }
  },
  //... (feel free to add more sample products across different categories)
];

//... (rest of your ProductService)


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  // Using a BehaviorSubject to allow subscription to product list updates
  private productsSubject = new BehaviorSubject<Product[]>(INITIAL_PRODUCTS);
  public products$: Observable<Product[]> = this.productsSubject.asObservable();

  constructor() { }

  // other CRUD methods will be added here

  // Add a new product to the list
  addProduct(newProduct: Product) {
    const currentProducts = this.productsSubject.getValue();
    const updatedProducts = [...currentProducts, newProduct];
    this.productsSubject.next(updatedProducts);
  }

  // Update an existing product
  updateProduct(updatedProduct: Product) {
    let currentProducts = this.productsSubject.getValue();
    const updatedProducts = currentProducts.map(product =>
      product.id === updatedProduct.id ? updatedProduct : product
    );
    this.productsSubject.next(updatedProducts);
  }

  // Delete a product by id
  deleteProduct(productId: number) {
    let currentProducts = this.productsSubject.getValue();
    const updatedProducts = currentProducts.filter(product => product.id !== productId);
    this.productsSubject.next(updatedProducts);
  }

  // Get a single product by id
  getProductById(productId: number): Product | undefined {
    const currentProducts = this.productsSubject.getValue();
    console.log('currentProducts', currentProducts);
    return currentProducts.find(product => product.id === productId);
  }

  // Method to "save" a new product
  saveProduct(productData: any): Observable<any> {
    // In a real app, here you would make an HTTP request to post the data to a server.
    // We're simulating saving the product by adding it to an array.
    let currentProducts = this.productsSubject.getValue();
    currentProducts.push(productData);
    this.productsSubject.next(currentProducts);
    return of(productData); // Simulate an Observable response
  }

  // (Optional) Method to retrieve all products
  getProducts(): Observable<any[]> {
    // In a real app, here you would return data from server.
    let currentProducts = this.productsSubject.getValue();
    return of(currentProducts);
  }
}
