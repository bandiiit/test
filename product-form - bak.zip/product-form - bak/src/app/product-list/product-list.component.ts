import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router'; // Import Router
import { ProductService, Product } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];

  @Output() productToView = new EventEmitter<Product>();

  constructor(
    private productService: ProductService,
    private router: Router  // Inject Router
  ) { }

  ngOnInit(): void {
    this.productService.products$.subscribe(products => {
      this.products = products;
    });
  }

  onEdit(product: Product): void {
    // Navigate to the 'Product Form' component for editing. 
    // Assuming 'product-edit' is a defined route that takes a product ID parameter.
    this.router.navigate(['/product', product.id]);
  }

  onDelete(productId: number): void {
    // this.productService.deleteProduct(productId).subscribe(() => {
    //   // After the product is deleted, you could refresh the list or remove the item from the array locally.
    //   this.products = this.products.filter(product => product.id !== productId);
    // });
    this.productService.deleteProduct(productId);
  }

  onAdd(): void {
    // Navigate to the 'Product Form' component to add a new product.
    // Assuming 'product-add' is a defined route.
    this.router.navigate(['/product']);
  }

  viewProduct(productId: number): void {
    this.router.navigate(['/product', productId]);
  }
}
