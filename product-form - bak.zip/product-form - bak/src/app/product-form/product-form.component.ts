import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';

import { ProductService } from '../product.service';
import { Product } from '../product.service';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {

  @Input() product: Product | null = null;

  productForm!: FormGroup;
  currentCategory!: string;

  isSubmitting: boolean = false;
  productId: number = 0;

  constructor(private fb: FormBuilder,
    private productService: ProductService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.productForm = new FormGroup({
      'name': new FormControl(null, Validators.required),
      'category': new FormControl(null, Validators.required),
      'price': new FormControl(null, Validators.required),
      'quantity': new FormControl(null, Validators.required)
      // ... other form controls
    });

    // this.productForm = this.fb.group({
    //   category: ['', Validators.required],
    //   name: ['', Validators.required],
    //   price: ['', Validators.required],
    //   quantity: ['', Validators.required],
    //   // Initially, no additional attributes until a category is selected
    // });

    // Subscribe to changes in the category field
    const categoryControl = this.productForm.get('category');
    if (categoryControl) {
      categoryControl.valueChanges.subscribe(value => {
        this.onCategoryChange(value);
      });
    } else {
      throw new Error('Category control is not found in the form');
    }

    this.route.params.subscribe((params: Params) => {
      this.productId = Number(params['id']);
      if (this.productId) {
        this.loadProduct();
      }
    });

    // Here we subscribe to the category's changes.
    this.productForm.get('category')?.valueChanges.subscribe((value: string) => {
      this.onCategoryChange(value);
    });
  }

  onCategoryChange(selectedCategory: string): void {
    console.log('Selected category', selectedCategory);
    console.log('Form before category change', this.productForm);
    // If the category changes, we reset the current category and remove previous controls
    if (this.currentCategory !== selectedCategory) {
      this.currentCategory = selectedCategory;
      this.resetCategorySpecificControls();
    }

    // Based on the category, we add new controls
    switch (selectedCategory) {
      case 'fruit':
        this.productForm.addControl('ripenessLevel', this.fb.control('', Validators.required));
        this.productForm.addControl('origin', this.fb.control('', Validators.required));
        break;
      case 'vegetable':
        this.productForm.addControl('size', this.fb.control('', Validators.required));
        this.productForm.addControl('type', this.fb.control('', Validators.required));
        break;
      case 'beverage':
        this.productForm.addControl('flavor', this.fb.control('', Validators.required));
        this.productForm.addControl('volume', this.fb.control('', Validators.required));
        break;
      case 'baking':
        this.productForm.addControl('packaging', this.fb.control('', Validators.required));
        break;
      default:
        // For an unknown category or for the default option, no specific controls are added
        break;
    }
    console.log('Form after category change', this.productForm);
  }

  resetCategorySpecificControls(): void {
    // Here we'll remove the controls added previously based on the category
    const controlsToRemove = ['ripenessLevel', 'origin', 'size', 'type', 'flavor', 'volume', 'packaging'];
    controlsToRemove.forEach(controlName => {
      if (this.productForm.contains(controlName)) {
        this.productForm.removeControl(controlName);
      }
    });
  }

  // Method to handle form submission
  onSubmit(): void {
    if (this.productForm.valid) {
      this.isSubmitting = true;
      const formData = this.productForm.value;

      // Use the product service to save the data
      this.productService.saveProduct(formData).subscribe(
        (response) => {
          // Handle the response here
          console.log('Product saved', response);
          alert('Product saved successfully!');
          this.isSubmitting = false;
          this.productForm.reset();
        },
        (error) => {
          // Handle errors here
          console.error('There was an error!', error);
          alert('Failed to save the product!');
          this.isSubmitting = false;
        }
      );
    }
  }
  
  // Now, use this type for the 'categoryControls' object:
  categoryControls: CategoryControls = {
    'fruit': ['ripenessLevel', 'origin'],
    'vegetable': ['size', 'type'],
    'beverage': ['flavor', 'volume'],
    'baking': ['packaging']
    // ... other categories with their controls
  };

  getControlsForCategory(category: string): string[] | undefined {
    return this.categoryControls[category];
  }

  // ... other utility methods specific to your needs can be added
  ngOnChanges(changes: SimpleChanges) {
    if (changes['product']) {
      this.loadProductData(this.product);
    }
  }

  loadProductData(product: Product | null) {
    if (!product) return;

    // Fill in the form with product data
    this.productForm.patchValue(product);

    // Disable the form
    this.productForm.disable();
  }

  loadProduct() {
    // Here, fetch the product using the ID, for instance, from an API or local storage
    // Assuming you have a service that gets the product details
    const product = this.productService.getProductById(this.productId);
    console.log('Product', product);
    if (product) {
      this.productForm.get('category')?.setValue(product.category);

      // Fill in the form with product data
      this.productForm.patchValue(product);

      // Disable the form
      this.productForm.disable();
    }
  }
}

interface CategoryControls {
  [key: string]: string[]; // This signifies that the object can have many keys (of type string), and each key's value is an array of strings.
}