# Project Start Up

1. up postgres and rabbitmq

> docker-compose up postgres rabbitmq

2. run application