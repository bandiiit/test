**Task:** Develop a teaching project (Order Management System) with a Master-Detail relationship.

**Technical Stack:**

- **Backend:** Java 8, Spring Boot 2.7.x, Spring Security, Spring Data JPA, H2 Database, Lombok.
- **Frontend:** Vue 3 (Composition API), Vite, Ant Design Vue, Pinia, Axios.

**Detailed Requirements:**

**1. Data Model (Master-Detail):**

- **Order:** `id`, `orderNumber`, `customerName`, `totalAmount`, `status`, `createTime`.
- **OrderItem:** `id`, `productId`, `productName`, `unitPrice`, `quantity`, `subtotal`.
- **Relationship:** One `Order` has many `OrderItems`.

**2. Backend Implementation (Java 8):**

- **Database:** Provide `schema.sql` and `data.sql`. Initialize `users` table with `admin` (ROLE_ADMIN) and `user` (ROLE_USER) using **BCrypt** passwords. Seed at least 3 orders, each with 2-3 line items.
- **Security:** Configure Session-based authentication. Implement `/api/login` and `/api/logout`.
- **Controller:**
  - `GET /api/orders`: Return list of orders (without line items for performance).
  - `GET /api/orders/{id}`: Return full order details including the list of `OrderItems`.
  - `DELETE /api/orders/{id}`: Restricted to `ROLE_ADMIN` via `@PreAuthorize`.
- **Best Practices:** Use a unified `Result<T>` wrapper. Configure CORS for Vue dev server.

**3. Frontend Implementation (Vue 3 + Ant Design Vue):**

- **Store:** Pinia for user session, persisted in `localStorage`.
- **Axios:** Request/Response interceptors for auth headers and global error handling.
- **Pages:**
  - `Login.vue`: Login form with redirection.
  - `OrderList.vue`: `a-table` showing high-level order info and an "Action" column to view details.
  - `OrderDetail.vue`:
    - Top section: `a-descriptions` for Order Header.
    - Bottom section: A secondary `a-table` for the Order Items.
    - Permission: "Delete Order" button visible only to `ADMIN`.

**Deliverables:**

- Full Java source code (Entity mapping, Repository, Service, Controller, SecurityConfig).
- SQL scripts.
- Complete Vue source (Axios config, Store, Router, and Components).