# Order Management Backend

A Spring Boot 2.7.x backend for the Order Management System with Master-Detail relationship.

## Build

```bash
mvn clean package
```

## Run

```bash
mvn spring-boot:run
```

The backend will run on `http://localhost:8080`.

## Database

The project uses H2 in-memory database with initialization scripts:
- `schema.sql` - Creates tables
- `data.sql` - Seeds sample data with admin and user accounts

### Demo Users

- **admin** (ROLE_ADMIN): admin123
- **user** (ROLE_USER): user123

## API Endpoints

- `POST /api/login` - User login
- `POST /api/logout` - User logout
- `GET /api/orders` - List all orders (authenticated)
- `GET /api/orders/{id}` - Get order details with items (authenticated)
- `DELETE /api/orders/{id}` - Delete order (admin only)

## Architecture

- **Entity**: Order, OrderItem, User
- **Repository**: Spring Data JPA repositories
- **Service**: Business logic layer
- **Controller**: REST API controllers
- **Config**: Security configuration with BCrypt password encoding
