-- Insert users with BCrypt encoded passwords
-- admin password: admin123 (encoded)
-- user password: user123 (encoded)
INSERT INTO users (username, password, role) VALUES 
('admin', '$2a$10$N6MqMFQ5qn8vQJoGhC2dW.hRPhYjAKQw70s6P4XVVSp1lnkxHKEYK', 'ROLE_ADMIN'),
('user', '$2a$10$hGHnDvQ4DJWGv.1dEqP2Oe0Tz8S0XzVjLJqI2M1Gof5oG6d/Ki4tK', 'ROLE_USER');

-- Insert sample orders
INSERT INTO orders (order_number, customer_name, total_amount, status, create_time) VALUES
('ORD-001', 'John Doe', 199.99, 'COMPLETED', '2024-01-10 10:00:00'),
('ORD-002', 'Jane Smith', 299.99, 'PENDING', '2024-01-11 14:30:00'),
('ORD-003', 'Bob Johnson', 449.99, 'SHIPPED', '2024-01-12 08:15:00');

-- Insert order items for Order 1
INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, subtotal) VALUES
(1, 101, 'Laptop', 999.99, 1, 999.99),
(1, 102, 'Mouse', 29.99, 2, 59.98);

-- Insert order items for Order 2
INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, subtotal) VALUES
(2, 103, 'Monitor', 299.99, 1, 299.99),
(2, 104, 'Keyboard', 79.99, 1, 79.99);

-- Insert order items for Order 3
INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, subtotal) VALUES
(3, 105, 'Headphones', 149.99, 2, 299.98),
(3, 106, 'USB Cable', 9.99, 3, 29.99);
