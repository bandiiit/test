package com.example.ordermanagement.controller;

import com.example.ordermanagement.dto.LoginRequest;
import com.example.ordermanagement.dto.LoginResponse;
import com.example.ordermanagement.dto.Result;
import com.example.ordermanagement.entity.User;
import com.example.ordermanagement.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AuthController {
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;

    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest loginRequest, HttpSession session) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getUsername(),
                            loginRequest.getPassword()
                    )
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);
            session.setAttribute("SPRING_SECURITY_CONTEXT", SecurityContextHolder.getContext());

            User user = userRepository.findByUsername(loginRequest.getUsername())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            LoginResponse response = new LoginResponse();
            response.setUsername(user.getUsername());
            response.setRole(user.getRole());
            response.setMessage("Login successful");

            return Result.success(response);
        } catch (AuthenticationException e) {
            return Result.error("Invalid username or password");
        }
    }

    @PostMapping("/logout")
    public Result<String> logout(HttpSession session) {
        SecurityContextHolder.clearContext();
        session.invalidate();
        return Result.success("Logout successful");
    }
}
