import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '../store/useUserStore'
import Login from '../components/Login.vue'
import OrderList from '../components/OrderList.vue'
import OrderDetail from '../components/OrderDetail.vue'

const routes = [
  {
    path: '/login',
    component: Login,
    meta: { requiresAuth: false }
  },
  {
    path: '/orders',
    component: OrderList,
    meta: { requiresAuth: true }
  },
  {
    path: '/orders/:id',
    component: OrderDetail,
    meta: { requiresAuth: true }
  },
  {
    path: '/',
    redirect: '/orders'
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const userStore = useUserStore()
  userStore.loadUser()

  if (to.meta.requiresAuth && !userStore.isLoggedIn) {
    next('/login')
  } else if (to.path === '/login' && userStore.isLoggedIn) {
    next('/orders')
  } else {
    next()
  }
})

export default router
