import axios from './axios'

export const login = (username, password) => {
  return axios.post('/login', { username, password })
}

export const logout = () => {
  return axios.post('/logout')
}

export const getAllOrders = () => {
  return axios.get('/orders')
}

export const getOrderById = (id) => {
  return axios.get(`/orders/${id}`)
}

export const deleteOrder = (id) => {
  return axios.delete(`/orders/${id}`)
}
