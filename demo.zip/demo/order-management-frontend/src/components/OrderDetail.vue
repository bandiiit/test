<template>
  <div class="order-detail-container">
    <a-layout>
      <a-layout-header style="background: #fff; padding: 0 20px; display: flex; justify-content: space-between; align-items: center;">
        <h2>Order Detail</h2>
        <div>
          <a-button @click="goBack" style="margin-right: 10px;">Back</a-button>
          <a-button type="primary" danger v-if="isAdmin" @click="handleDelete" :loading="deleteLoading">
            Delete Order
          </a-button>
        </div>
      </a-layout-header>

      <a-layout-content style="margin: 20px;">
        <a-spin :spinning="loading">
          <div v-if="order">
            <!-- Order Header -->
            <a-card title="Order Information" style="margin-bottom: 20px;">
              <a-descriptions bordered>
                <a-descriptions-item label="Order Number" :span="3">
                  {{ order.orderNumber }}
                </a-descriptions-item>
                <a-descriptions-item label="Customer Name" :span="3">
                  {{ order.customerName }}
                </a-descriptions-item>
                <a-descriptions-item label="Total Amount" :span="3">
                  ${{ order.totalAmount?.toFixed(2) || '0.00' }}
                </a-descriptions-item>
                <a-descriptions-item label="Status" :span="3">
                  <a-tag :color="getStatusColor(order.status)">
                    {{ order.status }}
                  </a-tag>
                </a-descriptions-item>
                <a-descriptions-item label="Create Time" :span="3">
                  {{ formatDate(order.createTime) }}
                </a-descriptions-item>
              </a-descriptions>
            </a-card>

            <!-- Order Items -->
            <a-card title="Order Items">
              <a-table
                :columns="itemColumns"
                :dataSource="order.items || []"
                rowKey="id"
                :pagination="false"
              >
                <template #bodyCell="{ column, record }">
                  <template v-if="column.key === 'unitPrice'">
                    ${{ record.unitPrice.toFixed(2) }}
                  </template>
                  <template v-else-if="column.key === 'subtotal'">
                    ${{ record.subtotal.toFixed(2) }}
                  </template>
                </template>
              </a-table>
            </a-card>
          </div>
          <a-empty v-else description="Order not found" />
        </a-spin>
      </a-layout-content>
    </a-layout>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '../store/useUserStore'
import { getOrderById, deleteOrder } from '../api/orderApi'
import { message } from 'ant-design-vue'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const order = ref(null)
const loading = ref(false)
const deleteLoading = ref(false)

const isAdmin = computed(() => userStore.user?.role === 'ROLE_ADMIN')

const itemColumns = [
  {
    title: 'Product Name',
    dataIndex: 'productName',
    key: 'productName',
    width: 200
  },
  {
    title: 'Unit Price',
    dataIndex: 'unitPrice',
    key: 'unitPrice',
    width: 120
  },
  {
    title: 'Quantity',
    dataIndex: 'quantity',
    key: 'quantity',
    width: 100
  },
  {
    title: 'Subtotal',
    dataIndex: 'subtotal',
    key: 'subtotal',
    width: 120
  }
]

const loadOrder = async () => {
  loading.value = true
  try {
    const response = await getOrderById(route.params.id)
    if (response.data.code === 0) {
      order.value = response.data.data
    }
  } catch (error) {
    message.error('Failed to load order')
  } finally {
    loading.value = false
  }
}

const getStatusColor = (status) => {
  const colors = {
    'COMPLETED': 'green',
    'PENDING': 'orange',
    'SHIPPED': 'blue',
    'CANCELLED': 'red'
  }
  return colors[status] || 'default'
}

const formatDate = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return date.toLocaleString()
}

const goBack = () => {
  router.back()
}

const handleDelete = async () => {
  deleteLoading.value = true
  try {
    const response = await deleteOrder(route.params.id)
    if (response.data.code === 0) {
      message.success('Order deleted successfully')
      router.push('/orders')
    } else {
      message.error(response.data.message || 'Failed to delete order')
    }
  } catch (error) {
    message.error('Failed to delete order')
  } finally {
    deleteLoading.value = false
  }
}

onMounted(() => {
  loadOrder()
})
</script>

<style scoped>
.order-detail-container {
  min-height: 100vh;
  background: #f5f5f5;
}
</style>
