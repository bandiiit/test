<template>
  <div class="order-list-container">
    <a-layout>
      <a-layout-header style="background: #fff; padding: 0 20px; display: flex; justify-content: space-between; align-items: center;">
        <h2>Order Management</h2>
        <div>
          <span style="margin-right: 20px;">Welcome, {{ userStore.user?.username }}!</span>
          <a-button type="primary" danger @click="handleLogout">Logout</a-button>
        </div>
      </a-layout-header>

      <a-layout-content style="margin: 20px;">
        <a-card title="Orders" :loading="loading">
          <a-table
            :columns="columns"
            :dataSource="orders"
            :loading="loading"
            rowKey="id"
            :pagination="{ pageSize: 10 }"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'action'">
                <a-space>
                  <a-button type="primary" size="small" @click="viewDetail(record.id)">
                    View Details
                  </a-button>
                </a-space>
              </template>
            </template>
          </a-table>
        </a-card>
      </a-layout-content>
    </a-layout>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../store/useUserStore'
import { getAllOrders, logout } from '../api/orderApi'

const router = useRouter()
const userStore = useUserStore()

const orders = ref([])
const loading = ref(false)

const columns = [
  {
    title: 'Order Number',
    dataIndex: 'orderNumber',
    key: 'orderNumber',
    width: 150
  },
  {
    title: 'Customer Name',
    dataIndex: 'customerName',
    key: 'customerName',
    width: 150
  },
  {
    title: 'Total Amount',
    dataIndex: 'totalAmount',
    key: 'totalAmount',
    width: 120,
    customRender: ({ text }) => `$${text.toFixed(2)}`
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    width: 100
  },
  {
    title: 'Create Time',
    dataIndex: 'createTime',
    key: 'createTime',
    width: 180
  },
  {
    title: 'Action',
    key: 'action',
    width: 150
  }
]

const loadOrders = async () => {
  loading.value = true
  try {
    const response = await getAllOrders()
    if (response.data.code === 0) {
      orders.value = response.data.data || []
    }
  } catch (error) {
    console.error('Failed to load orders:', error)
  } finally {
    loading.value = false
  }
}

const viewDetail = (id) => {
  router.push(`/orders/${id}`)
}

const handleLogout = async () => {
  try {
    await logout()
    userStore.clearUser()
    router.push('/login')
  } catch (error) {
    console.error('Logout failed:', error)
  }
}

onMounted(() => {
  loadOrders()
})
</script>

<style scoped>
.order-list-container {
  min-height: 100vh;
  background: #f5f5f5;
}
</style>
