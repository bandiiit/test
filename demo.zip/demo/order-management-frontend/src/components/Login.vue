<template>
  <div class="login-container">
    <a-card title="Order Management System" style="width: 400px">
      <a-form layout="vertical" @finish="handleLogin">
        <a-form-item label="Username" name="username" :rules="[{ required: true, message: 'Please input username!' }]">
          <a-input v-model:value="form.username" placeholder="Enter username" />
        </a-form-item>

        <a-form-item label="Password" name="password" :rules="[{ required: true, message: 'Please input password!' }]">
          <a-input-password v-model:value="form.password" placeholder="Enter password" />
        </a-form-item>

        <a-form-item>
          <a-button type="primary" html-type="submit" block :loading="loading">
            Login
          </a-button>
        </a-form-item>

        <a-alert v-if="error" :message="error" type="error" showIcon closable @close="error = null" />

        <p style="margin-top: 10px; color: #666;">
          Demo credentials:<br/>
          admin / admin123<br/>
          user / user123
        </p>
      </a-form>
    </a-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../store/useUserStore'
import { login } from '../api/orderApi'

const router = useRouter()
const userStore = useUserStore()

const form = ref({ username: '', password: '' })
const loading = ref(false)
const error = ref(null)

const handleLogin = async () => {
  loading.value = true
  error.value = null

  try {
    const response = await login(form.username, form.password)
    if (response.data.code === 0) {
      userStore.setUser(response.data.data)
      router.push('/orders')
    } else {
      error.value = response.data.message || 'Login failed'
    }
  } catch (err) {
    error.value = err.response?.data?.message || 'Login failed'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
</style>
