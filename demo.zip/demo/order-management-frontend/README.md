# Order Management Frontend

A Vue 3 + Ant Design Vue frontend for the Order Management System.

## Setup

```bash
npm install
```

## Development

```bash
npm run dev
```

The frontend will run on `http://localhost:5173` and will proxy API requests to `http://localhost:8080`.

## Build

```bash
npm run build
```

## Demo Credentials

- **Admin**: admin / admin123
- **User**: user / user123
