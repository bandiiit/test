# Sync Order Service

Minimal Spring Boot 2.7 producer–consumer example with Outbox pattern and result feedback over RabbitMQ.

## Tech
- Java 8
- Spring Boot 2.7.x
- Spring AMQP (RabbitMQ)
- H2 in-memory DB
- Maven Wrapper

## Run RabbitMQ
```bash
docker run -d --name rabbit -p 5672:5672 -p 15672:15672 rabbitmq:3.12-management
```

## Start Producer
```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=producer
```

## Start Consumer
```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=consumer
```

## Create Order
```bash
curl -X POST http://localhost:8080/orders
```

Example response contains `orderNumber`.

## Query Order
```bash
curl http://localhost:8080/orders/{orderNumber}
```

## Notes
- Outbox publisher scans pending/failed rows and publishes commands with retries.
- Consumer randomly simulates success/failure and returns a result.
- Producer consumes results and updates the order status.

