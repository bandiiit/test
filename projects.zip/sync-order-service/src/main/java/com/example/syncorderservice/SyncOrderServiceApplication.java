package com.example.syncorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SyncOrderServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(SyncOrderServiceApplication.class, args);
    }
}


