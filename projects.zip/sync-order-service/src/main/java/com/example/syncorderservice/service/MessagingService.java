package com.example.syncorderservice.service;

import com.example.syncorderservice.dto.OrderCommand;
import com.example.syncorderservice.dto.OrderResult;
import com.example.syncorderservice.messaging.MessagingConfig;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.stereotype.Service;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
public class MessagingService {
    private final RabbitTemplate rabbitTemplate;

    public MessagingService(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendCommand(OrderCommand command) {
        rabbitTemplate.convertAndSend(MessagingConfig.ORDER_EXCHANGE, MessagingConfig.ORDER_COMMAND_QUEUE, command,
                message -> message, new CorrelationData(command.getOrderNumber()));
    }

    public void sendResult(OrderResult result) {
        CorrelationData cd = new CorrelationData(result.getCorrelationId() != null ? result.getCorrelationId() : result.getOrderNumber());
        rabbitTemplate.convertAndSend(MessagingConfig.ORDER_EXCHANGE, MessagingConfig.ORDER_RESULT_QUEUE, result,
                message -> message, cd);
        // Wait for publisher confirm; throw if nack/timeout
        try {
            CorrelationData.Confirm confirm = cd.getFuture().get(10, TimeUnit.SECONDS);
            if (!confirm.isAck()) {
                throw new IllegalStateException("Broker NACK for correlationId=" + cd.getId());
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting for publisher confirm", ie);
        } catch (ExecutionException | TimeoutException ex) {
            throw new IllegalStateException("Failed to get publisher confirm for correlationId=" + cd.getId(), ex);
        }
    }
}


