package com.example.syncorderservice.service;

import com.example.syncorderservice.dto.OrderCommand;
import com.example.syncorderservice.dto.OrderResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CommandProcessingService {
    private static final Logger log = LoggerFactory.getLogger(CommandProcessingService.class);

    private final Random random = new Random();
    // Lightweight idempotency cache (in-memory for demo)
    private final Map<String, OrderResult> processedByOrderNumber = new ConcurrentHashMap<>();

    @Transactional
    public OrderResult process(OrderCommand command) {
        String orderNumber = command.getOrderNumber();

        // Idempotency: return previous result if already processed
        OrderResult cached = processedByOrderNumber.get(orderNumber);
        if (cached != null) {
            log.info("Order {} was already processed. Returning cached result.", orderNumber);
            return cached;
        }

        // Business logic that may throw
        OrderResult result = OrderResult.builder().orderNumber(orderNumber).build();
        applyBusinessFields(result, command);

        boolean success = random.nextBoolean();
        result.setSuccess(success);
        if (!success) {
            result.setErrorMessage("Simulated failure");
        }

        // Store outcome for idempotency
        processedByOrderNumber.put(orderNumber, result);
        return result;
    }

    private void applyBusinessFields(OrderResult result, OrderCommand command) {
        // Example business step that could throw
        result.setOrderNumber(command.getOrderNumber());
    }
}


