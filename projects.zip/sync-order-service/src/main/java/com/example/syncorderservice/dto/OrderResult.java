package com.example.syncorderservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderResult {
    private String orderNumber;
    private boolean success;
    private String errorMessage;
    private String correlationId;
}


