package com.example.syncorderservice.messaging;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableRabbit
public class MessagingConfig {
    public static final String ORDER_EXCHANGE = "order.exchange";
    public static final String ORDER_COMMAND_QUEUE = "order.command";
    public static final String ORDER_RESULT_QUEUE = "order.result";

    @Bean
    public DirectExchange orderExchange() {
        return new DirectExchange(ORDER_EXCHANGE);
    }

    @Bean
    public Queue orderCommandQueue() {
        return new Queue(ORDER_COMMAND_QUEUE, true);
    }

    @Bean
    public Queue orderResultQueue() {
        return new Queue(ORDER_RESULT_QUEUE, true);
    }

    @Bean
    public Binding commandBinding(Queue orderCommandQueue, DirectExchange orderExchange) {
        return BindingBuilder.bind(orderCommandQueue).to(orderExchange).with(ORDER_COMMAND_QUEUE);
    }

    @Bean
    public Binding resultBinding(Queue orderResultQueue, DirectExchange orderExchange) {
        return BindingBuilder.bind(orderResultQueue).to(orderExchange).with(ORDER_RESULT_QUEUE);
    }

    @Bean
    public Jackson2JsonMessageConverter jackson2JsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(org.springframework.amqp.rabbit.connection.ConnectionFactory connectionFactory,
                                         Jackson2JsonMessageConverter messageConverter) {
        if (connectionFactory instanceof CachingConnectionFactory) {
            ((CachingConnectionFactory) connectionFactory).setPublisherConfirmType(CachingConnectionFactory.ConfirmType.CORRELATED);
            ((CachingConnectionFactory) connectionFactory).setPublisherReturns(true);
        }
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(messageConverter);
        template.setMandatory(true);
        return template;
    }
}


