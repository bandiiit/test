package com.example.syncorderservice.domain;

public enum OutboxStatus {
    PENDING,
    PUBLISHED,
    FAILED
}


