package com.example.syncorderservice.scheduler;

import com.example.syncorderservice.domain.Outbox;
import com.example.syncorderservice.dto.OrderCommand;
import com.example.syncorderservice.service.MessagingService;
import com.example.syncorderservice.service.OutboxService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@EnableScheduling
@Profile("producer")
public class OutboxPublisher {
    private static final Logger log = LoggerFactory.getLogger(OutboxPublisher.class);

    private final OutboxService outboxService;
    private final MessagingService messagingService;
    private final ObjectMapper objectMapper;
    private final int retryLimit;

    public OutboxPublisher(OutboxService outboxService,
                           MessagingService messagingService,
                           ObjectMapper objectMapper,
                           @Value("${outbox.retry-limit:3}") int retryLimit) {
        this.outboxService = outboxService;
        this.messagingService = messagingService;
        this.objectMapper = objectMapper;
        this.retryLimit = retryLimit;
    }

    @Scheduled(fixedDelayString = "${outbox.publisher.delay-ms:2000}")
    public void publishPending() {
        List<Outbox> outboxes = outboxService.getPendingOrRetryOutboxRows();
        for (Outbox outbox : outboxes) {
            if (outbox.getRetryCount() > retryLimit) {
                log.warn("Outbox {} exceeded retry limit", outbox.getId());
                continue;
            }
            try {
                OrderCommand command = objectMapper.readValue(outbox.getPayload(), OrderCommand.class);
                messagingService.sendCommand(command);
                outboxService.markPublished(outbox);
            } catch (Exception e) {
                log.error("Failed to publish outbox {}: {}", outbox.getId(), e.getMessage());
                outboxService.markFailed(outbox);
            }
        }
    }
}


