package com.example.syncorderservice.messaging;

import com.example.syncorderservice.domain.OrderStatus;
import com.example.syncorderservice.dto.OrderResult;
import com.example.syncorderservice.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("producer")
public class ResultListener {
    private static final Logger log = LoggerFactory.getLogger(ResultListener.class);

    private final OrderService orderService;

    public ResultListener(OrderService orderService) {
        this.orderService = orderService;
    }

    @RabbitListener(queues = MessagingConfig.ORDER_RESULT_QUEUE)
    public void onResult(OrderResult result) {
        log.info("Received result for order {}: {}", result.getOrderNumber(), result.isSuccess());
        orderService.updateOrderStatus(result.getOrderNumber(),
                result.isSuccess() ? OrderStatus.SUCCESS : OrderStatus.FAILURE,
                result.getErrorMessage());
    }
}


