package com.example.syncorderservice.service;

import com.example.syncorderservice.domain.Order;
import com.example.syncorderservice.domain.OrderStatus;
import com.example.syncorderservice.domain.Outbox;
import com.example.syncorderservice.repository.OrderRepository;
import com.example.syncorderservice.repository.OutboxRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
public class OrderService {
    private final OrderRepository orderRepository;
    private final OutboxRepository outboxRepository;

    public OrderService(OrderRepository orderRepository, OutboxRepository outboxRepository) {
        this.orderRepository = orderRepository;
        this.outboxRepository = outboxRepository;
    }

    @Transactional
    public Order createOrderWithOutbox() {
        Order order = new Order();
        order.setOrderNumber(UUID.randomUUID().toString());
        order.setStatus(OrderStatus.PENDING);
        order.setCreatedAt(Instant.now());
        order.setUpdatedAt(Instant.now());
        order = orderRepository.save(order);

        Outbox outbox = new Outbox();
        outbox.setAggregateId(order.getOrderNumber());
        outbox.setMessageType("ORDER_COMMAND");
        // Minimal payload for command processing
        String payload = "{\"orderNumber\":\"" + order.getOrderNumber() + "\"}";
        outbox.setPayload(payload);
        outboxRepository.save(outbox);

        return order;
    }

    @Transactional(readOnly = true)
    public Optional<Order> getByOrderNumber(String orderNumber) {
        return orderRepository.findByOrderNumber(orderNumber);
    }

    @Transactional
    public void updateOrderStatus(String orderNumber, OrderStatus status, String errorMessage) {
        orderRepository.findByOrderNumber(orderNumber).ifPresent(order -> {
            order.setStatus(status);
            order.setUpdatedAt(Instant.now());
            if (status == OrderStatus.SUCCESS || status == OrderStatus.FAILURE || status == OrderStatus.TIMEOUT) {
                order.setProcessedAt(Instant.now());
            }
            order.setErrorMessage(errorMessage);
            orderRepository.save(order);
        });
    }
}


