package com.example.syncorderservice.messaging;

import com.example.syncorderservice.dto.OrderCommand;
import com.example.syncorderservice.dto.OrderResult;
import com.example.syncorderservice.service.MessagingService;
import com.example.syncorderservice.service.CommandProcessingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.Random;

@Component
@Profile("consumer")
public class CommandListener {
    private static final Logger log = LoggerFactory.getLogger(CommandListener.class);

    private final MessagingService messagingService;
    private final CommandProcessingService commandProcessingService;
    private final Random random = new Random();

    public CommandListener(MessagingService messagingService,
                           CommandProcessingService commandProcessingService) {
        this.messagingService = messagingService;
        this.commandProcessingService = commandProcessingService;
    }

    @RabbitListener(queues = MessagingConfig.ORDER_COMMAND_QUEUE)
    public void onCommand(OrderCommand command) {
        log.info("Received command for order {}", command.getOrderNumber());
        OrderResult result;
        try {
            // Delegate to transactional service (service is annotated @Transactional)
            result = commandProcessingService.process(command);
        } catch (Exception ex) {
            log.error("Business error while processing order {}", command.getOrderNumber(), ex);
            // Ensure a failure response is still sent back to producer
            result = OrderResult.builder()
                    .orderNumber(command.getOrderNumber())
                    .success(false)
                    .errorMessage("Processing error: " + ex.getMessage())
                    .build();
        }

        // Safeguard non-null result
        if (result == null) {
            result = OrderResult.builder()
                    .orderNumber(command.getOrderNumber())
                    .success(false)
                    .errorMessage("Processing produced no result")
                    .build();
        }

        // Set correlation id
        if (result.getCorrelationId() == null) {
            result.setCorrelationId(command.getOrderNumber());
        }

        // Send reliably; if publish fails, rethrow to trigger container retry
        try {
            messagingService.sendResult(result);
        } catch (Exception sendEx) {
            log.error("Failed to publish result for order {}", command.getOrderNumber(), sendEx);
            throw sendEx instanceof RuntimeException ? (RuntimeException) sendEx : new RuntimeException(sendEx);
        }
    }

    // Deprecated: business logic moved to CommandProcessingService
}


