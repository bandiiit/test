package com.example.syncorderservice.domain;

public enum OrderStatus {
    PENDING,
    SUCCESS,
    FAILURE,
    TIMEOUT
}


