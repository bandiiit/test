package com.example.syncorderservice.service;

import com.example.syncorderservice.domain.Outbox;
import com.example.syncorderservice.domain.OutboxStatus;
import com.example.syncorderservice.repository.OutboxRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;

@Service
public class OutboxService {
    private final OutboxRepository outboxRepository;

    public OutboxService(OutboxRepository outboxRepository) {
        this.outboxRepository = outboxRepository;
    }

    @Transactional(readOnly = true)
    public List<Outbox> getPendingOrRetryOutboxRows() {
        return outboxRepository.findTop50ByStatusInOrderByCreatedAtAsc(Arrays.asList(OutboxStatus.PENDING, OutboxStatus.FAILED));
    }

    @Transactional
    public void markPublished(Outbox outbox) {
        outbox.setStatus(OutboxStatus.PUBLISHED);
        outbox.setPublishedAt(Instant.now());
        outboxRepository.save(outbox);
    }

    @Transactional
    public void markFailed(Outbox outbox) {
        outbox.setStatus(OutboxStatus.FAILED);
        outbox.setRetryCount(outbox.getRetryCount() + 1);
        outboxRepository.save(outbox);
    }
}


