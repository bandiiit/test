package com.example.ordersync.listener;

import com.example.ordersync.dto.OrderCommand;
import com.example.ordersync.dto.OrderResult;
import com.example.ordersync.model.Order;
import com.example.ordersync.model.OrderStatus;
import com.example.ordersync.repository.OrderRepository;
import com.example.ordersync.service.MessagePublisher;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Optional;

@Component
public class OrderCommandListener {

    private static final Logger logger = LoggerFactory.getLogger(OrderCommandListener.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private MessagePublisher messagePublisher;

    @Autowired
    private ObjectMapper objectMapper;

    @RabbitListener(queues = "${rabbitmq.queue.command:order.command.queue}")
    public void handleOrderCommand(String message) {
        try {
            logger.info("Received order command: {}", message);
            
            OrderCommand command = objectMapper.readValue(message, OrderCommand.class);
            
            // Check if order already processed (idempotency)
            Optional<Order> existingOrder = orderRepository.findByOrderNumber(command.getOrderNumber());
            if (existingOrder.isPresent() && existingOrder.get().getStatus() != OrderStatus.PENDING) {
                logger.info("Order already processed: {}", command.getOrderNumber());
                return;
            }

            // Process the order
            OrderResult result = processOrder(command);
            
            // Publish result
            String resultPayload = objectMapper.writeValueAsString(result);
            messagePublisher.publishResultMessage(resultPayload);
            
            logger.info("Order processed successfully: {}", command.getOrderNumber());
            
        } catch (Exception e) {
            logger.error("Failed to process order command: {}", message, e);
            // In a real scenario, you might want to publish a failure result
        }
    }

    private OrderResult processOrder(OrderCommand command) {
        logger.info("Processing order: {}", command.getOrderNumber());
        
        try {
            // Simulate business logic processing
            Thread.sleep(1000); // Simulate processing time
            
            // Simulate some failures for testing
            if (command.getOrderNumber().contains("FAIL")) {
                throw new RuntimeException("Simulated processing failure");
            }
            
            // Update order status to SUCCESS
            Optional<Order> orderOpt = orderRepository.findByOrderNumber(command.getOrderNumber());
            if (orderOpt.isPresent()) {
                Order order = orderOpt.get();
                order.setStatus(OrderStatus.SUCCESS);
                order.setProcessedAt(LocalDateTime.now());
                orderRepository.save(order);
            }
            
            return new OrderResult(command.getOrderId(), command.getOrderNumber(), 
                                 "SUCCESS", "Order processed successfully");
            
        } catch (Exception e) {
            logger.error("Order processing failed: {}", command.getOrderNumber(), e);
            
            // Update order status to FAILURE
            Optional<Order> orderOpt = orderRepository.findByOrderNumber(command.getOrderNumber());
            if (orderOpt.isPresent()) {
                Order order = orderOpt.get();
                order.setStatus(OrderStatus.FAILURE);
                order.setProcessedAt(LocalDateTime.now());
                order.setErrorMessage(e.getMessage());
                orderRepository.save(order);
            }
            
            return new OrderResult(command.getOrderId(), command.getOrderNumber(), 
                                 "FAILURE", e.getMessage());
        }
    }
}
