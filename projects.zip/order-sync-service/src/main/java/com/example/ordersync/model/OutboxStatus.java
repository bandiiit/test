package com.example.ordersync.model;

public enum OutboxStatus {
    PENDING,
    PUBLISHED,
    FAILED
}
