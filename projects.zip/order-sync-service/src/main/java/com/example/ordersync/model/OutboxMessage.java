package com.example.ordersync.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "OUTBOX")
public class OutboxMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ORDER_ID", nullable = false)
    @NotNull
    private Long orderId;

    @Column(name = "MESSAGE_TYPE", nullable = false)
    @NotNull
    private String messageType;

    @Column(name = "MESSAGE_PAYLOAD", nullable = false, columnDefinition = "CLOB")
    @NotNull
    private String messagePayload;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false)
    private OutboxStatus status = OutboxStatus.PENDING;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @Column(name = "PUBLISHED_AT")
    private LocalDateTime publishedAt;

    @Column(name = "RETRY_COUNT")
    private Integer retryCount = 0;

    // Constructors
    public OutboxMessage() {
        this.createdAt = LocalDateTime.now();
    }

    public OutboxMessage(Long orderId, String messageType, String messagePayload) {
        this();
        this.orderId = orderId;
        this.messageType = messageType;
        this.messagePayload = messagePayload;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessagePayload() {
        return messagePayload;
    }

    public void setMessagePayload(String messagePayload) {
        this.messagePayload = messagePayload;
    }

    public OutboxStatus getStatus() {
        return status;
    }

    public void setStatus(OutboxStatus status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getPublishedAt() {
        return publishedAt;
    }

    public void setPublishedAt(LocalDateTime publishedAt) {
        this.publishedAt = publishedAt;
    }

    public Integer getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(Integer retryCount) {
        this.retryCount = retryCount;
    }
}
