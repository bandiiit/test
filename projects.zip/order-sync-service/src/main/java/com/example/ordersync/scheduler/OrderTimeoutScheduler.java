package com.example.ordersync.scheduler;

import com.example.ordersync.model.Order;
import com.example.ordersync.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class OrderTimeoutScheduler {

    private static final Logger logger = LoggerFactory.getLogger(OrderTimeoutScheduler.class);

    @Autowired
    private OrderService orderService;

    @Value("${order.timeout.minutes:5}")
    private int timeoutMinutes;

    @Scheduled(fixedDelay = 60000) // Run every minute
    public void checkTimeoutOrders() {
        try {
            logger.debug("Checking for timeout orders (timeout: {} minutes)", timeoutMinutes);
            
            List<Order> timeoutOrders = orderService.getTimeoutOrders(timeoutMinutes);
            
            if (!timeoutOrders.isEmpty()) {
                logger.info("Found {} timeout orders", timeoutOrders.size());
                
                for (Order order : timeoutOrders) {
                    orderService.markOrderAsTimeout(order.getId());
                }
            }
            
        } catch (Exception e) {
            logger.error("Error checking timeout orders", e);
        }
    }
}
