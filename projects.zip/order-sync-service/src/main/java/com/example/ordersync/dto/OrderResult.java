package com.example.ordersync.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;

public class OrderResult {

    @JsonProperty("orderId")
    @NotNull
    private Long orderId;

    @JsonProperty("orderNumber")
    @NotNull
    private String orderNumber;

    @JsonProperty("status")
    @NotNull
    private String status;

    @JsonProperty("message")
    private String message;

    @JsonProperty("timestamp")
    private Long timestamp;

    // Constructors
    public OrderResult() {
        this.timestamp = System.currentTimeMillis();
    }

    public OrderResult(Long orderId, String orderNumber, String status, String message) {
        this();
        this.orderId = orderId;
        this.orderNumber = orderNumber;
        this.status = status;
        this.message = message;
    }

    // Getters and Setters
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
