package com.example.ordersync.repository;

import com.example.ordersync.model.OutboxMessage;
import com.example.ordersync.model.OutboxStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OutboxRepository extends JpaRepository<OutboxMessage, Long> {

    List<OutboxMessage> findByStatus(OutboxStatus status);

    List<OutboxMessage> findByOrderId(Long orderId);

    @Query("SELECT o FROM OutboxMessage o WHERE o.status = :status AND o.retryCount < :maxRetries ORDER BY o.createdAt ASC")
    List<OutboxMessage> findPendingMessagesWithRetryLimit(@Param("status") OutboxStatus status, 
                                                         @Param("maxRetries") Integer maxRetries);

    @Query("SELECT o FROM OutboxMessage o WHERE o.status = :status AND o.createdAt < :timeoutThreshold")
    List<OutboxMessage> findTimeoutMessages(@Param("status") OutboxStatus status, 
                                           @Param("timeoutThreshold") LocalDateTime timeoutThreshold);
}
