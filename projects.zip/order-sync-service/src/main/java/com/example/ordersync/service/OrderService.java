package com.example.ordersync.service;

import com.example.ordersync.dto.OrderCommand;
import com.example.ordersync.dto.OrderResult;
import com.example.ordersync.model.Order;
import com.example.ordersync.model.OrderStatus;
import com.example.ordersync.model.OutboxMessage;
import com.example.ordersync.model.OutboxStatus;
import com.example.ordersync.repository.OrderRepository;
import com.example.ordersync.repository.OutboxRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OutboxRepository outboxRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MessagePublisher messagePublisher;

    @Transactional
    public Order createOrder(String customerId, String productId, Integer quantity, BigDecimal amount) {
        logger.info("Creating order for customer: {}, product: {}, quantity: {}", customerId, productId, quantity);

        String orderNumber = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Order order = new Order(orderNumber, customerId, productId, quantity, amount);
        order = orderRepository.save(order);

        // Create outbox message for command
        try {
            OrderCommand command = new OrderCommand(order.getId(), order.getOrderNumber(), 
                                                  customerId, productId, quantity, amount);
            String payload = objectMapper.writeValueAsString(command);
            
            OutboxMessage outboxMessage = new OutboxMessage(order.getId(), "ORDER_COMMAND", payload);
            outboxRepository.save(outboxMessage);
            
            logger.info("Created order: {} with outbox message", order.getOrderNumber());
        } catch (JsonProcessingException e) {
            logger.error("Failed to create outbox message for order: {}", order.getOrderNumber(), e);
            throw new RuntimeException("Failed to create outbox message", e);
        }

        return order;
    }

    @Transactional
    public void processOrderResult(OrderResult result) {
        logger.info("Processing order result for order: {}, status: {}", result.getOrderNumber(), result.getStatus());

        Optional<Order> orderOpt = orderRepository.findByOrderNumber(result.getOrderNumber());
        if (!orderOpt.isPresent()) {
            logger.warn("Order not found for result: {}", result.getOrderNumber());
            return;
        }

        Order order = orderOpt.get();
        OrderStatus newStatus = OrderStatus.valueOf(result.getStatus());
        order.setStatus(newStatus);
        order.setProcessedAt(LocalDateTime.now());
        
        if ("FAILURE".equals(result.getStatus())) {
            order.setErrorMessage(result.getMessage());
        }

        orderRepository.save(order);
        logger.info("Updated order: {} status to: {}", order.getOrderNumber(), newStatus);
    }

    @Transactional
    public void markOrderAsTimeout(Long orderId) {
        logger.info("Marking order as timeout: {}", orderId);

        Optional<Order> orderOpt = orderRepository.findById(orderId);
        if (orderOpt.isPresent()) {
            Order order = orderOpt.get();
            if (order.getStatus() == OrderStatus.PENDING) {
                order.setStatus(OrderStatus.TIMEOUT);
                order.setErrorMessage("Order processing timeout");
                orderRepository.save(order);
                logger.info("Marked order as timeout: {}", order.getOrderNumber());
            }
        }
    }

    public List<Order> getOrdersByStatus(OrderStatus status) {
        return orderRepository.findByStatus(status);
    }

    public List<Order> getPendingAndFailedOrders() {
        return orderRepository.findPendingAndFailedOrders();
    }

    public List<Order> getTimeoutOrders(int timeoutMinutes) {
        LocalDateTime timeoutThreshold = LocalDateTime.now().minusMinutes(timeoutMinutes);
        return orderRepository.findTimeoutOrders(OrderStatus.PENDING, timeoutThreshold);
    }

    public Optional<Order> getOrderByNumber(String orderNumber) {
        return orderRepository.findByOrderNumber(orderNumber);
    }
}
