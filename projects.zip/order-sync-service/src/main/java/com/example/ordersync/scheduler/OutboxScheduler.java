package com.example.ordersync.scheduler;

import com.example.ordersync.service.MessagePublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class OutboxScheduler {

    private static final Logger logger = LoggerFactory.getLogger(OutboxScheduler.class);

    @Autowired
    private MessagePublisher messagePublisher;

    @Scheduled(fixedDelay = 30000) // Run every 30 seconds
    public void publishPendingMessages() {
        try {
            logger.debug("Publishing pending outbox messages");
            messagePublisher.publishPendingMessages();
        } catch (Exception e) {
            logger.error("Error publishing pending messages", e);
        }
    }

    @Scheduled(fixedDelay = 60000) // Run every minute
    public void retryFailedMessages() {
        try {
            logger.debug("Retrying failed outbox messages");
            messagePublisher.retryFailedMessages();
        } catch (Exception e) {
            logger.error("Error retrying failed messages", e);
        }
    }
}
