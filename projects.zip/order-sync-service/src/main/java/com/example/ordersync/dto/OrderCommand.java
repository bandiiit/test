package com.example.ordersync.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;

public class OrderCommand {

    @JsonProperty("orderId")
    @NotNull
    private Long orderId;

    @JsonProperty("orderNumber")
    @NotNull
    private String orderNumber;

    @JsonProperty("customerId")
    @NotNull
    private String customerId;

    @JsonProperty("productId")
    @NotNull
    private String productId;

    @JsonProperty("quantity")
    @Positive
    private Integer quantity;

    @JsonProperty("amount")
    @NotNull
    private BigDecimal amount;

    @JsonProperty("timestamp")
    private Long timestamp;

    // Constructors
    public OrderCommand() {
        this.timestamp = System.currentTimeMillis();
    }

    public OrderCommand(Long orderId, String orderNumber, String customerId, 
                       String productId, Integer quantity, BigDecimal amount) {
        this();
        this.orderId = orderId;
        this.orderNumber = orderNumber;
        this.customerId = customerId;
        this.productId = productId;
        this.quantity = quantity;
        this.amount = amount;
    }

    // Getters and Setters
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
