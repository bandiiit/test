package com.example.ordersync.service;

import com.example.ordersync.model.OutboxMessage;
import com.example.ordersync.model.OutboxStatus;
import com.example.ordersync.repository.OutboxRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MessagePublisher {

    private static final Logger logger = LoggerFactory.getLogger(MessagePublisher.class);

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private OutboxRepository outboxRepository;

    @Value("${rabbitmq.exchange.command:order.command.exchange}")
    private String commandExchange;

    @Value("${rabbitmq.exchange.result:order.result.exchange}")
    private String resultExchange;

    @Value("${rabbitmq.routing-key.command:order.command}")
    private String commandRoutingKey;

    @Value("${rabbitmq.routing-key.result:order.result}")
    private String resultRoutingKey;

    @Transactional
    public void publishCommandMessage(OutboxMessage outboxMessage) {
        try {
            logger.info("Publishing command message for order: {}", outboxMessage.getOrderId());
            
            rabbitTemplate.convertAndSend(commandExchange, commandRoutingKey, outboxMessage.getMessagePayload());
            
            outboxMessage.setStatus(OutboxStatus.PUBLISHED);
            outboxMessage.setPublishedAt(LocalDateTime.now());
            outboxRepository.save(outboxMessage);
            
            logger.info("Successfully published command message for order: {}", outboxMessage.getOrderId());
        } catch (Exception e) {
            logger.error("Failed to publish command message for order: {}", outboxMessage.getOrderId(), e);
            outboxMessage.setStatus(OutboxStatus.FAILED);
            outboxMessage.setRetryCount(outboxMessage.getRetryCount() + 1);
            outboxRepository.save(outboxMessage);
            throw e;
        }
    }

    @Transactional
    public void publishResultMessage(String messagePayload) {
        try {
            logger.info("Publishing result message");
            
            rabbitTemplate.convertAndSend(resultExchange, resultRoutingKey, messagePayload);
            
            logger.info("Successfully published result message");
        } catch (Exception e) {
            logger.error("Failed to publish result message", e);
            throw e;
        }
    }

    @Transactional
    public void retryFailedMessages() {
        logger.info("Retrying failed outbox messages");
        
        List<OutboxMessage> failedMessages = outboxRepository.findPendingMessagesWithRetryLimit(OutboxStatus.FAILED, 3);
        
        for (OutboxMessage message : failedMessages) {
            try {
                if ("ORDER_COMMAND".equals(message.getMessageType())) {
                    publishCommandMessage(message);
                }
            } catch (Exception e) {
                logger.error("Failed to retry message: {}", message.getId(), e);
            }
        }
    }

    @Transactional
    public void publishPendingMessages() {
        logger.info("Publishing pending outbox messages");
        
        List<OutboxMessage> pendingMessages = outboxRepository.findByStatus(OutboxStatus.PENDING);
        
        for (OutboxMessage message : pendingMessages) {
            try {
                if ("ORDER_COMMAND".equals(message.getMessageType())) {
                    publishCommandMessage(message);
                }
            } catch (Exception e) {
                logger.error("Failed to publish pending message: {}", message.getId(), e);
            }
        }
    }
}
