package com.example.ordersync.listener;

import com.example.ordersync.dto.OrderResult;
import com.example.ordersync.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderResultListener {

    private static final Logger logger = LoggerFactory.getLogger(OrderResultListener.class);

    @Autowired
    private OrderService orderService;

    @Autowired
    private ObjectMapper objectMapper;

    @RabbitListener(queues = "${rabbitmq.queue.result:order.result.queue}")
    public void handleOrderResult(String message) {
        try {
            logger.info("Received order result: {}", message);
            
            OrderResult result = objectMapper.readValue(message, OrderResult.class);
            orderService.processOrderResult(result);
            
            logger.info("Order result processed: {}", result.getOrderNumber());
            
        } catch (Exception e) {
            logger.error("Failed to process order result: {}", message, e);
        }
    }
}
