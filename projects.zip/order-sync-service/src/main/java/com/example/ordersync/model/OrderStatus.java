package com.example.ordersync.model;

public enum OrderStatus {
    PENDING,
    SUCCESS,
    FAILURE,
    TIMEOUT
}
