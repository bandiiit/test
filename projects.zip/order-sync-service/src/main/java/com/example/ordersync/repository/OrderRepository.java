package com.example.ordersync.repository;

import com.example.ordersync.model.Order;
import com.example.ordersync.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Optional<Order> findByOrderNumber(String orderNumber);

    List<Order> findByStatus(OrderStatus status);

    @Query("SELECT o FROM Order o WHERE o.status = :status AND o.createdAt < :timeoutThreshold")
    List<Order> findTimeoutOrders(@Param("status") OrderStatus status, 
                                 @Param("timeoutThreshold") LocalDateTime timeoutThreshold);

    @Query("SELECT o FROM Order o WHERE o.status IN ('PENDING', 'FAILURE') ORDER BY o.createdAt ASC")
    List<Order> findPendingAndFailedOrders();
}
