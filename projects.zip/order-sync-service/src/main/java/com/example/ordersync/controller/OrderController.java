package com.example.ordersync.controller;

import com.example.ordersync.model.Order;
import com.example.ordersync.model.OrderStatus;
import com.example.ordersync.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<Order> createOrder(@Valid @RequestBody CreateOrderRequest request) {
        Order order = orderService.createOrder(
            request.getCustomerId(),
            request.getProductId(),
            request.getQuantity(),
            request.getAmount()
        );
        return ResponseEntity.ok(order);
    }

    @GetMapping("/{orderNumber}")
    public ResponseEntity<Order> getOrder(@PathVariable String orderNumber) {
        Optional<Order> order = orderService.getOrderByNumber(orderNumber);
        return order.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Order>> getOrdersByStatus(@PathVariable OrderStatus status) {
        List<Order> orders = orderService.getOrdersByStatus(status);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/pending")
    public ResponseEntity<List<Order>> getPendingOrders() {
        List<Order> orders = orderService.getPendingAndFailedOrders();
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/timeout")
    public ResponseEntity<List<Order>> getTimeoutOrders(@RequestParam(defaultValue = "5") int timeoutMinutes) {
        List<Order> orders = orderService.getTimeoutOrders(timeoutMinutes);
        return ResponseEntity.ok(orders);
    }

    public static class CreateOrderRequest {
        @NotBlank
        private String customerId;

        @NotBlank
        private String productId;

        @NotNull
        @Positive
        private Integer quantity;

        @NotNull
        private BigDecimal amount;

        // Getters and Setters
        public String getCustomerId() {
            return customerId;
        }

        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }

        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public void setQuantity(Integer quantity) {
            this.quantity = quantity;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }
    }
}
