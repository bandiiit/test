# Oracle Database Initialization Scripts

This directory contains SQL scripts for initializing the Oracle database schema.

## Files

- `01-create-schema.sql` - Main schema creation script that creates:
  - `ORDERS` table: stores order information with status tracking
  - `OUTBOX` table: implements outbox pattern for reliable messaging
  - Indexes: for performance optimization
  - Triggers: for automatic timestamp updates
  - Sample data: for testing purposes

## Usage

The script is automatically executed by the Oracle container during initialization. It runs when the container starts for the first time.

## Manual Execution

To run the script manually:

```bash
sqlplus system/oracle@localhost:1521/XE @01-create-schema.sql
```

## Schema Details

### ORDERS Table
- Tracks order lifecycle with status: PENDING, SUCCESS, FAILURE, TIMEOUT
- Includes audit fields: created_at, updated_at, processed_at
- Stores error messages for failed orders

### OUTBOX Table
- Implements outbox pattern for reliable message publishing
- Tracks message status: PENDING, PUBLISHED, FAILED
- Includes retry count for failed messages

## Prerequisites

- Oracle database running
- System user with DBA privileges
- SQL*Plus or similar SQL client
