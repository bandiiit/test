#!/bin/bash

set -e

# Set RabbitMQ connection details
RABBITMQ_HOST=${RABBITMQ_HOST:-rabbitmq}
RABBITMQ_PORT=${RABBITMQ_PORT:-5672}
RABBITMQ_MANAGEMENT_PORT=${RABBITMQ_MANAGEMENT_PORT:-15672}
RABBITMQ_DEFAULT_USER=${RABBITMQ_DEFAULT_USER:-admin}
RABBITMQ_DEFAULT_PASS=${RABBITMQ_DEFAULT_PASS:-admin123}

echo "Connecting to RabbitMQ at $RABBITMQ_HOST:$RABBITMQ_PORT"

# Wait for RabbitMQ Management API to be ready (no curl in this image; use rabbitmqadmin)
echo "Waiting for RabbitMQ management to be ready..."
for i in {1..60}; do
  if rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT \
       -u $RABBITMQ_DEFAULT_USER -p $RABBITMQ_DEFAULT_PASS \
       list vhosts > /dev/null 2>&1; then
    echo "RabbitMQ management is ready!"
    break
  fi
  echo "Attempt $i/60: management not ready, waiting..."
  sleep 2
done

# Wait a bit more for management plugin to be ready
echo "Waiting for management plugin to be ready..."
sleep 5

echo "RabbitMQ is ready, setting up infrastructure..."

# Create vhost (idempotent)
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT \
  -u $RABBITMQ_DEFAULT_USER -p $RABBITMQ_DEFAULT_PASS \
  declare vhost name=order_sync

# Create user (idempotent)
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT \
  -u $RABBITMQ_DEFAULT_USER -p $RABBITMQ_DEFAULT_PASS \
  declare user name=order_user password=order_password tags=management

# Set permissions
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT \
  -u $RABBITMQ_DEFAULT_USER -p $RABBITMQ_DEFAULT_PASS \
  declare permission vhost=order_sync user=order_user configure=.* write=.* read=.*

# Now declare exchanges/queues/bindings using order_user
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT \
  -u order_user -p order_password -V order_sync declare exchange name=order.command.exchange type=topic durable=true

# rabbitmqadmin confirmed ready above

# Create exchanges
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare exchange name=order.command.exchange type=topic durable=true
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare exchange name=order.result.exchange type=topic durable=true
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare exchange name=order.dlx.exchange type=topic durable=true
echo "Created exchanges: order.command.exchange, order.result.exchange, order.dlx.exchange"

# Create main queues
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare queue name=order.command.queue durable=true arguments='{"x-queue-type":"quorum","x-message-ttl":300000}'
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare queue name=order.result.queue durable=true arguments='{"x-queue-type":"quorum","x-message-ttl":300000}'
echo "Created main queues: order.command.queue, order.result.queue"

# Create retry queues
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare queue name=order.command.retry.queue durable=true arguments='{"x-queue-type":"quorum","x-message-ttl":60000,"x-dead-letter-exchange":"order.command.exchange","x-dead-letter-routing-key":"order.command"}'
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare queue name=order.result.retry.queue durable=true arguments='{"x-queue-type":"quorum","x-message-ttl":60000,"x-dead-letter-exchange":"order.result.exchange","x-dead-letter-routing-key":"order.result"}'
echo "Created retry queues: order.command.retry.queue, order.result.retry.queue"

# Create dead letter queues
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare queue name=order.command.dlq durable=true arguments='{"x-queue-type":"quorum"}'
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare queue name=order.result.dlq durable=true arguments='{"x-queue-type":"quorum"}'
echo "Created dead letter queues: order.command.dlq, order.result.dlq"

# Create bindings for main queues
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare binding source=order.command.exchange destination=order.command.queue routing_key=order.command
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare binding source=order.result.exchange destination=order.result.queue routing_key=order.result
echo "Created bindings for main queues"

# Create bindings for retry queues
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare binding source=order.dlx.exchange destination=order.command.retry.queue routing_key=order.command.retry
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare binding source=order.dlx.exchange destination=order.result.retry.queue routing_key=order.result.retry
echo "Created bindings for retry queues"

# Create bindings for dead letter queues
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare binding source=order.dlx.exchange destination=order.command.dlq routing_key=order.command.dlq
rabbitmqadmin -H $RABBITMQ_HOST -P $RABBITMQ_MANAGEMENT_PORT -u order_user -p order_password -V order_sync declare binding source=order.dlx.exchange destination=order.result.dlq routing_key=order.result.dlq
echo "Created bindings for dead letter queues"

echo "RabbitMQ setup completed successfully!"
