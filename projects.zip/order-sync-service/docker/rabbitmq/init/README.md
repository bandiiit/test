# RabbitMQ Initialization Scripts

This directory contains scripts for initializing RabbitMQ infrastructure.

## Files

- `01-setup-rabbitmq.sh` - Main initialization script that sets up:
  - Virtual host: `order_sync`
  - User: `order_user` with password `order_password`
  - Exchanges: command, result, and dead letter exchanges
  - Queues: main queues, retry queues, and dead letter queues
  - Bindings: routing configuration between exchanges and queues

## Usage

The script is automatically executed by the `rabbit-init` container in Docker Compose. It waits for RabbitMQ to be ready and then sets up all the required infrastructure.

## Manual Execution

To run the script manually:

```bash
chmod +x 01-setup-rabbitmq.sh
./01-setup-rabbitmq.sh
```

## Prerequisites

- RabbitMQ server running
- `rabbitmqctl` and `rabbitmqadmin` tools available
- User with administrative privileges
