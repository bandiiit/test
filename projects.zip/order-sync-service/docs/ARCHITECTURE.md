# Order Sync Service - Architecture Design

## 1. Objectives

The Order Sync Service implements a reliable, distributed order processing system that ensures:

- **Reliability**: Orders are never lost and processing results are guaranteed to be communicated back
- **Consistency**: Order status is always accurate and reflects the actual processing state
- **Fault Tolerance**: System handles failures gracefully with retry mechanisms and dead letter queues
- **Observability**: Full traceability of order processing with timeout detection
- **Scalability**: Producer and consumer can be scaled independently

## 2. Architecture Overview

The system follows a **Producer-Consumer pattern** with **Result Feedback** using:

- **Spring Boot 2.7** with Java 8
- **Oracle Free 23c** for persistent storage
- **RabbitMQ** for reliable message queuing
- **Docker Compose** for one-click deployment

### 2.1 System Components

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Producer      │    │   RabbitMQ      │    │   Consumer      │
│   (Order API)   │───▶│   (Message      │───▶│   (Order        │
│                 │    │    Broker)      │    │    Processor)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Oracle DB     │    │   DLQ/Retry     │    │   Result        │
│   (Orders +     │    │   Queues        │    │   Feedback      │
│   Outbox)       │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 3. Data Flow

### 3.1 Order Creation Flow

1. **Client** sends order creation request to **Producer API**
2. **Producer** creates order record in `ORDERS` table with status `PENDING`
3. **Producer** creates outbox message in `OUTBOX` table
4. **Outbox Scheduler** publishes command message to RabbitMQ
5. **Consumer** receives command and processes the order
6. **Consumer** publishes result message back to RabbitMQ
7. **Producer** receives result and updates order status

### 3.2 Message Types

- **Command Message**: `OrderCommand` - Contains order details for processing
- **Result Message**: `OrderResult` - Contains processing result (SUCCESS/FAILURE)

## 4. Reliability Mechanisms

### 4.1 Outbox Pattern

- Ensures **exactly-once** message delivery
- Messages are stored in database before publishing
- Failed publishes are retried automatically
- Prevents message loss during system failures

### 4.2 Dead Letter Queues (DLQ)

- **Retry Queues**: Messages are retried with exponential backoff
- **Dead Letter Queues**: Messages that fail after max retries
- **TTL-based Requeuing**: Automatic retry mechanism

### 4.3 Idempotency

- Consumer checks if order is already processed
- Prevents duplicate processing of the same order
- Ensures consistent state even with message redelivery

### 4.4 Timeout Handling

- **Scheduled Task**: Monitors pending orders every minute
- **Configurable Timeout**: Default 5 minutes
- **Automatic Status Update**: Marks orders as `TIMEOUT`

## 5. Database Schema

### 5.1 ORDERS Table

```sql
CREATE TABLE ORDERS (
    ID NUMBER(19) PRIMARY KEY,
    ORDER_NUMBER VARCHAR2(50) UNIQUE NOT NULL,
    CUSTOMER_ID VARCHAR2(50) NOT NULL,
    PRODUCT_ID VARCHAR2(50) NOT NULL,
    QUANTITY NUMBER(10) NOT NULL,
    AMOUNT NUMBER(19,2) NOT NULL,
    STATUS VARCHAR2(20) NOT NULL DEFAULT 'PENDING',
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UPDATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PROCESSED_AT TIMESTAMP,
    ERROR_MESSAGE CLOB
);
```

**Status Values:**
- `PENDING`: Order created, waiting for processing
- `SUCCESS`: Order processed successfully
- `FAILURE`: Order processing failed
- `TIMEOUT`: Order processing timed out

### 5.2 OUTBOX Table

```sql
CREATE TABLE OUTBOX (
    ID NUMBER(19) PRIMARY KEY,
    ORDER_ID NUMBER(19) NOT NULL,
    MESSAGE_TYPE VARCHAR2(50) NOT NULL,
    MESSAGE_PAYLOAD CLOB NOT NULL,
    STATUS VARCHAR2(20) NOT NULL DEFAULT 'PENDING',
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PUBLISHED_AT TIMESTAMP,
    RETRY_COUNT NUMBER(3) DEFAULT 0
);
```

**Status Values:**
- `PENDING`: Message not yet published
- `PUBLISHED`: Message successfully published
- `FAILED`: Message publishing failed

## 6. RabbitMQ Configuration

### 6.1 Exchanges

- **order.command.exchange**: Routes command messages to consumer
- **order.result.exchange**: Routes result messages back to producer
- **order.dlx.exchange**: Dead letter exchange for failed messages

### 6.2 Queues

- **order.command.queue**: Main command processing queue
- **order.result.queue**: Main result processing queue
- **order.command.retry.queue**: Retry queue for failed commands
- **order.result.retry.queue**: Retry queue for failed results
- **order.command.dlq**: Dead letter queue for commands
- **order.result.dlq**: Dead letter queue for results

### 6.3 Queue Properties

- **Durable**: Survives broker restarts
- **Quorum**: High availability and consistency
- **TTL**: Automatic message expiration
- **DLX**: Dead letter exchange for failed messages

## 7. Failure Handling

### 7.1 Producer Failures

- **Database Transaction**: Order creation is atomic
- **Outbox Recovery**: Failed messages are retried on restart
- **Health Checks**: Container health monitoring

### 7.2 Consumer Failures

- **Message Acknowledgment**: Only after successful processing
- **Retry Logic**: Automatic retry with exponential backoff
- **Dead Letter Queue**: Failed messages after max retries

### 7.3 Network Failures

- **Connection Resilience**: Automatic reconnection
- **Message Persistence**: Messages survive broker restarts
- **Circuit Breaker**: Prevents cascade failures

## 8. Service Level Objectives (SLOs)

### 8.1 Availability

- **Target**: 99.9% uptime
- **Monitoring**: Health checks every 30 seconds
- **Recovery**: Automatic restart on failure

### 8.2 Performance

- **Order Processing**: < 2 seconds average
- **Message Latency**: < 100ms average
- **Throughput**: 100 orders/second

### 8.3 Reliability

- **Message Delivery**: 99.99% success rate
- **Data Consistency**: 100% consistency
- **Timeout Detection**: < 1 minute detection time

## 9. Monitoring and Observability

### 9.1 Health Checks

- **Application Health**: `/actuator/health`
- **Database Connectivity**: Connection pool status
- **RabbitMQ Connectivity**: Connection status

### 9.2 Metrics

- **Order Processing Rate**: Orders per second
- **Message Queue Depth**: Pending messages
- **Error Rates**: Failed processing percentage
- **Response Times**: API response times

### 9.3 Logging

- **Structured Logging**: JSON format for easy parsing
- **Correlation IDs**: Track requests across services
- **Error Tracking**: Detailed error information

## 10. Deployment Architecture

### 10.1 Docker Compose Services

- **oracle**: Database with init scripts
- **rabbitmq**: Message broker with management UI
- **rabbit-init**: Initialization container for RabbitMQ setup
- **producer-app**: Order creation and result handling
- **consumer-app**: Order processing

### 10.2 Startup Dependencies

- **rabbit-init** waits for **rabbitmq**
- **producer-app** waits for **rabbit-init** and **oracle**
- **consumer-app** waits for **rabbit-init** and **oracle**

### 10.3 Health Checks

- All services have health check endpoints
- Startup dependencies ensure proper initialization
- Automatic restart on health check failures

## 11. Security Considerations

### 11.1 Database Security

- **Connection Encryption**: TLS for database connections
- **Credential Management**: Environment variables for secrets
- **Access Control**: Limited database permissions

### 11.2 Message Security

- **Virtual Hosts**: Isolated message routing
- **User Authentication**: Dedicated RabbitMQ users
- **Network Isolation**: Docker network segmentation

## 12. Scalability Considerations

### 12.1 Horizontal Scaling

- **Producer Scaling**: Multiple producer instances
- **Consumer Scaling**: Multiple consumer instances
- **Load Balancing**: Round-robin message distribution

### 12.2 Resource Optimization

- **Connection Pooling**: Efficient database connections
- **Message Batching**: Batch processing for high throughput
- **Memory Management**: JVM tuning for optimal performance

This architecture ensures a robust, scalable, and maintainable order processing system that meets enterprise-grade reliability requirements.
