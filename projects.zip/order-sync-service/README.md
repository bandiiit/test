# Order Sync Service — Quick Start & Test Guide

## Prerequisites
- Docker and Docker Compose
- Make (optional; use Git Bash/WSL on Windows)

## 1) Clone and configure
```bash
git clone <your-repo-url>
cd order-sync-service
cp env.example .env   # Optional: customize ports/credentials
```

## 2) Start the stack
Recommended (Make):
```bash
make up
```
Or directly with Docker Compose:
```bash
docker compose up --build -d
```

Starts:
- Oracle Free 23c (schema init)
- RabbitMQ (management enabled)
- Rabbit initializer (vhost/users/queues/bindings)
- Producer app (profile=producer)
- Consumer app (profile=consumer)

## 3) Verify services
```bash
make status
make health
make logs-rabbitmq
make logs-producer
make logs-consumer
```

URLs:
- Producer API: http://localhost:8080
- Consumer API: http://localhost:8081
- RabbitMQ UI:  http://localhost:15672  (admin/admin123)

## 4) Create a sample order
Using Make:
```bash
make create-order
```
Or with curl:
```bash
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{"customerId":"CUST-001","productId":"PROD-001","quantity":2,"amount":99.98}'
```

## 5) Observe processing
Flow:
1. Producer writes order + outbox
2. Outbox publisher sends command to RabbitMQ
3. Consumer processes and publishes result
4. Producer consumes result and updates order status

Check orders:
```bash
make get-orders      # All by status
make get-pending
make get-timeout
```

## 6) Troubleshooting
- First boot may take 60–90s for Oracle/RabbitMQ
- Logs:
```bash
make logs-oracle
make logs-rabbitmq
make logs
```
- Reset (clears volumes):
```bash
make reset
```

## 7) Stop the stack
```bash
make down
```

See `docs/ARCHITECTURE.md` for full design details.


