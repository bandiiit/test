package example.controller;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
public class BookController {
    private static final List<Book> books = new ArrayList<>();

    static {
        for (int i = 1; i <= 30; i++) {
            books.add(Book.buildRandomBook(i));
        }
    }

    @GetMapping("/api/books")
    public Page<Book> findBooks(Pageable pageable,
                                @RequestParam(required = false) String title,
                                @RequestParam(required = false) String author) {
        List<Book> content = books.stream().filter(book -> book.title.contains(title))
                .filter(book -> book.author.contains(author))
                .skip(pageable.getOffset())
                .limit(pageable.getPageSize())
                .collect(Collectors.toList());
        return new PageImpl<>(content, pageable, books.size());
    }

    @Data
    @ToString
    @EqualsAndHashCode
    @NoArgsConstructor
    @AllArgsConstructor
    static class Book {
        private Integer id;
        private String title;
        private String author;

        static Book buildRandomBook(Integer id) {
            Book book = new Book();
            String strUuid = UUID.randomUUID().toString();
            book.setId(id);
            book.setTitle(strUuid);
            book.setAuthor(strUuid.substring(0, 5).toUpperCase());
            return book;
        }
    }
}
