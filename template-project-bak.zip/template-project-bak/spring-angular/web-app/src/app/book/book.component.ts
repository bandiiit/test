import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { HttpClient, HttpParams } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';

import { BookDialogComponent } from '../book-dialog/book-dialog.component';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  displayedColumns: string[] = ['actions', 'id', 'title', 'author'];
  dataSource = new MatTableDataSource([
    { id: 1, title: 'Book 1', author: 'Author 1' },
    { id: 2, title: 'Book 2', author: 'Author 2' },
    // ... Add more books
  ]);

  // Pagination
  length = 100;  // Initialize with a default value, later get it from server
  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 25, 100];

  // Filters
  titleFilter: string = '';
  authorFilter: string = '';

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;

  constructor(
    private httpClient: HttpClient,
    public dialog: MatDialog
  ) { } // Inject HttpClient

  ngOnInit() {
    this.loadData(0, this.pageSize, this.titleFilter, this.authorFilter);
  }

  // Handle paginator's events
  handlePageEvent(event: PageEvent) {
    this.loadData(event.pageIndex, event.pageSize, this.titleFilter, this.authorFilter);
  }

  // Function to handle button click
  applySearch() {
    this.loadData(0, this.pageSize, this.titleFilter, this.authorFilter);
  }

  // Load data from API
  loadData(pageIndex: number, pageSize: number, title: string, author: string) {
    const params = new HttpParams()
      .set('page', pageIndex.toString())
      .set('size', pageSize.toString())
      .set('title', title)
      .set('author', author);

    this.httpClient.get<any>('http://localhost:8080/api/books', { params })
      .subscribe(data => {
        this.dataSource.data = data.content;
        this.length = data.totalElements;
      });
  }

  openAddDialog(): void {
    const dialogRef = this.dialog.open(BookDialogComponent, {
      data: { book: {}, isEdit: false }
    });
  
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // Add book through your API
      }
    });
  }
  
  openEditDialog(row: any): void {
    const dialogRef = this.dialog.open(BookDialogComponent, {
      data: { book: { ...row }, isEdit: true }
    });
  
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // Edit book through your API
      }
    });
  }

  deleteBook(id: number) {
    // Delete the book through your API
  }
}

interface Book {
  id: number;
  title: string;
  author: string;
}
