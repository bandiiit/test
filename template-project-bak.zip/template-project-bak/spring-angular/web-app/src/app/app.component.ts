import { Component, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'web-app';

  @ViewChild('sidenav') sidenav!: MatSidenav;

  toggleSideNav() {
    this.sidenav.toggle();
  }
}
