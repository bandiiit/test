# Spring SOAP Time Tracking

Spring Boot sample application with two SOAP client services for Workday Time Tracking:

- `SpringWsTimeTrackingClient` uses Spring Web Services.
- `CxfTimeTrackingClient` uses Apache CXF.

Both clients call the WSDL operations:

- `Get_Time_Requests`
- `Put_Time_Clock_Events`

Update the endpoint in `src/main/resources/application.yml`:

```yaml
time-tracking:
  soap:
    endpoint-url: "https://example.workday.com/ccx/service/tenant/Time_Tracking/v46.1"
    username: "api-username"
    password: "api-password"
    log-messages: true
    log-payload-max-chars: 20000
```

## WS-Security UsernameToken

Both SOAP clients add a WS-Security `UsernameToken` to every request.

Process steps:

1. Create one API username-password pair for the Time Tracking API in the target system.
2. Set `time-tracking.soap.username` and `time-tracking.soap.password`.
3. Keep the endpoint in `time-tracking.soap.endpoint-url`.
4. Inject either `SpringWsTimeTrackingClient` or `CxfTimeTrackingClient`.
5. Call `getTimeRequests(...)` or `putTimeClockEvents(...)`; the client adds the `wsse:Security` header.

## SOAP Logging

Request and response logging is enabled by `time-tracking.soap.log-messages`.

- Spring WS logs request, response, and fault messages through `TimeTrackingSoapLoggingInterceptor`.
- CXF logs inbound and outbound SOAP messages through CXF logging interceptors.
- Use `time-tracking.soap.log-payload-max-chars` to cap large Workday payloads.
- Keep log access restricted because SOAP payloads can contain business data. The Spring WS and CXF loggers mask WS-Security password values before writing logs.

Generate sources and build:

```bash
mvn clean verify
```
