package com.example.timetracking.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.ws.test.client.RequestMatchers.payload;
import static org.springframework.ws.test.client.ResponseCreators.withPayload;

import com.example.timetracking.config.SpringWsClientConfig;
import com.example.timetracking.config.TimeTrackingSoapLoggingInterceptor;
import com.example.timetracking.config.TimeTrackingSoapProperties;
import com.example.timetracking.workday.GetTimeRequestsRequestType;
import com.example.timetracking.workday.GetTimeRequestsResponseType;
import com.example.timetracking.workday.ObjectFactory;
import com.example.timetracking.workday.PutTimeClockEventsRequestType;
import com.example.timetracking.workday.PutTimeClockEventsResponseType;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.test.client.RequestMatcher;
import org.springframework.ws.test.client.MockWebServiceServer;
import org.springframework.xml.transform.StringSource;

class SpringWsTimeTrackingClientTest {

    private static final String ENDPOINT_URL = "https://example.test/workday/Time_Tracking";
    private static final String USERNAME = "time-tracking-api-user";
    private static final String PASSWORD = "time-tracking-api-password";

    private MockWebServiceServer server;
    private SpringWsTimeTrackingClient client;

    @BeforeEach
    void setUp() throws Exception {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(ObjectFactory.class.getPackageName());
        marshaller.afterPropertiesSet();
        SpringWsClientConfig config = new SpringWsClientConfig();
        TimeTrackingSoapProperties properties = properties();
        WebServiceTemplate template = config.timeTrackingWebServiceTemplate(
                marshaller,
                config.timeTrackingWss4jSecurityInterceptor(properties),
                new TimeTrackingSoapLoggingInterceptor(properties));

        server = MockWebServiceServer.createServer(template);
        client = new SpringWsTimeTrackingClient(template, properties);
    }

    @Test
    void getTimeRequestsSendsExpectedPayloadAndReturnsResponse() {
        server.expect(payload(new StringSource(
                        "<wd:Get_Time_Requests_Request xmlns:wd=\"urn:com.workday/bsvc\"/>")))
                .andExpect(usernameToken())
                .andRespond(withPayload(new StringSource(
                        "<wd:Get_Time_Requests_Response xmlns:wd=\"urn:com.workday/bsvc\"/>")));

        GetTimeRequestsResponseType response = client.getTimeRequests(new GetTimeRequestsRequestType());

        assertThat(response).isNotNull();
        server.verify();
    }

    @Test
    void putTimeClockEventsSendsExpectedPayloadAndReturnsResponse() {
        server.expect(payload(new StringSource(
                        "<wd:Put_Time_Clock_Events_Request xmlns:wd=\"urn:com.workday/bsvc\"/>")))
                .andExpect(usernameToken())
                .andRespond(withPayload(new StringSource(
                        "<wd:Put_Time_Clock_Events_Response xmlns:wd=\"urn:com.workday/bsvc\"/>")));

        PutTimeClockEventsResponseType response = client.putTimeClockEvents(new PutTimeClockEventsRequestType());

        assertThat(response).isNotNull();
        server.verify();
    }

    private TimeTrackingSoapProperties properties() {
        return new TimeTrackingSoapProperties(
                ENDPOINT_URL,
                USERNAME,
                PASSWORD,
                Duration.ofSeconds(1),
                Duration.ofSeconds(1));
    }

    private RequestMatcher usernameToken() {
        return (uri, message) -> {
            String request = soapMessage(message);
            assertThat(request)
                    .contains("UsernameToken")
                    .contains("<wsse:Username>" + USERNAME + "</wsse:Username>")
                    .contains("<wsse:Password")
                    .contains(PASSWORD);
        };
    }

    private String soapMessage(org.springframework.ws.WebServiceMessage message) {
        try {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            message.writeTo(output);
            return output.toString(StandardCharsets.UTF_8.name());
        } catch (IOException ex) {
            throw new AssertionError("Unable to read SOAP request", ex);
        }
    }
}
