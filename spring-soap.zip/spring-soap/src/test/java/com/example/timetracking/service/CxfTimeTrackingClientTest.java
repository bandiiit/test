package com.example.timetracking.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.timetracking.config.TimeTrackingSoapProperties;
import com.example.timetracking.workday.GetTimeRequestsRequestType;
import com.example.timetracking.workday.GetTimeRequestsResponseType;
import com.example.timetracking.workday.PutTimeClockEventsRequestType;
import com.example.timetracking.workday.PutTimeClockEventsResponseType;
import com.sun.net.httpserver.HttpServer;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CxfTimeTrackingClientTest {

    private static final String USERNAME = "time-tracking-api-user";
    private static final String PASSWORD = "time-tracking-api-password";

    private HttpServer server;
    private List<String> requests;
    private CxfTimeTrackingClient client;

    @BeforeEach
    void setUp() throws IOException {
        requests = new ArrayList<>();
        server = HttpServer.create(new InetSocketAddress("localhost", 0), 0);
        server.createContext("/time-tracking", exchange -> {
            String requestBody = readBody(exchange.getRequestBody());
            requests.add(requestBody);

            String responseBody = responseFor(requestBody);
            byte[] responseBytes = responseBody.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "text/xml; charset=UTF-8");
            exchange.sendResponseHeaders(200, responseBytes.length);
            exchange.getResponseBody().write(responseBytes);
            exchange.close();
        });
        server.start();

        String endpointUrl = String.format("http://localhost:%d/time-tracking", server.getAddress().getPort());
        client = new CxfTimeTrackingClient(
                new TimeTrackingSoapProperties(
                        endpointUrl,
                        USERNAME,
                        PASSWORD,
                        Duration.ofSeconds(1),
                        Duration.ofSeconds(1)));
    }

    @AfterEach
    void tearDown() {
        server.stop(0);
    }

    @Test
    void getTimeRequestsUsesConfiguredEndpointAndReturnsResponse() {
        GetTimeRequestsResponseType response = client.getTimeRequests(new GetTimeRequestsRequestType());

        assertThat(response).isNotNull();
        assertThat(requests).singleElement().satisfies(request ->
                assertThat(request)
                        .contains("Get_Time_Requests_Request")
                        .contains("UsernameToken")
                        .contains("<wsse:Username>" + USERNAME + "</wsse:Username>")
                        .contains(PASSWORD));
    }

    @Test
    void putTimeClockEventsUsesConfiguredEndpointAndReturnsResponse() {
        PutTimeClockEventsResponseType response = client.putTimeClockEvents(new PutTimeClockEventsRequestType());

        assertThat(response).isNotNull();
        assertThat(requests).singleElement().satisfies(request ->
                assertThat(request)
                        .contains("Put_Time_Clock_Events_Request")
                        .contains("UsernameToken")
                        .contains("<wsse:Username>" + USERNAME + "</wsse:Username>")
                        .contains(PASSWORD));
    }

    private String responseFor(String requestBody) {
        if (requestBody.contains("Put_Time_Clock_Events_Request")) {
            return soapEnvelope("Put_Time_Clock_Events_Response");
        }
        return soapEnvelope("Get_Time_Requests_Response");
    }

    private String soapEnvelope(String responseElement) {
        return String.format(
                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                        + "<soap:Body>"
                        + "<wd:%s xmlns:wd=\"urn:com.workday/bsvc\"/>"
                        + "</soap:Body>"
                        + "</soap:Envelope>",
                responseElement);
    }

    private String readBody(InputStream inputStream) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int read;
        while ((read = inputStream.read(buffer)) != -1) {
            output.write(buffer, 0, read);
        }
        return output.toString(StandardCharsets.UTF_8.name());
    }
}
