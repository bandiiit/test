package com.example.timetracking.config;

import com.example.timetracking.workday.ObjectFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.security.wss4j2.Wss4jSecurityInterceptor;

@Configuration
public class SpringWsClientConfig {

    @Bean
    public Jaxb2Marshaller workdayMarshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(ObjectFactory.class.getPackageName());
        return marshaller;
    }

    @Bean
    public Wss4jSecurityInterceptor timeTrackingWss4jSecurityInterceptor(
            TimeTrackingSoapProperties properties) {
        Wss4jSecurityInterceptor interceptor = new Wss4jSecurityInterceptor();
        interceptor.setSecurementActions("UsernameToken");
        interceptor.setSecurementUsername(properties.getUsername());
        interceptor.setSecurementPassword(properties.getPassword());
        interceptor.setSecurementPasswordType("PasswordText");
        return interceptor;
    }

    @Bean
    public WebServiceTemplate timeTrackingWebServiceTemplate(
            Jaxb2Marshaller workdayMarshaller,
            Wss4jSecurityInterceptor timeTrackingWss4jSecurityInterceptor,
            TimeTrackingSoapLoggingInterceptor timeTrackingSoapLoggingInterceptor) {
        WebServiceTemplate template = new WebServiceTemplate(workdayMarshaller);
        template.setUnmarshaller(workdayMarshaller);
        template.setInterceptors(new ClientInterceptor[] {
                timeTrackingWss4jSecurityInterceptor,
                timeTrackingSoapLoggingInterceptor
        });
        return template;
    }
}
