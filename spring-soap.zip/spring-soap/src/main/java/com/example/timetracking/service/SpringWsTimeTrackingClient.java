package com.example.timetracking.service;

import com.example.timetracking.config.TimeTrackingSoapProperties;
import com.example.timetracking.workday.GetTimeRequestsRequestType;
import com.example.timetracking.workday.GetTimeRequestsResponseType;
import com.example.timetracking.workday.ObjectFactory;
import com.example.timetracking.workday.PutTimeClockEventsRequestType;
import com.example.timetracking.workday.PutTimeClockEventsResponseType;
import javax.xml.bind.JAXBElement;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

@Service
public class SpringWsTimeTrackingClient implements TimeTrackingOperations {

    private final WebServiceTemplate webServiceTemplate;
    private final TimeTrackingSoapProperties properties;
    private final ObjectFactory objectFactory = new ObjectFactory();

    public SpringWsTimeTrackingClient(
            WebServiceTemplate timeTrackingWebServiceTemplate,
            TimeTrackingSoapProperties properties) {
        this.webServiceTemplate = timeTrackingWebServiceTemplate;
        this.properties = properties;
    }

    @Override
    public GetTimeRequestsResponseType getTimeRequests(GetTimeRequestsRequestType request) {
        JAXBElement<GetTimeRequestsResponseType> response = send(
                objectFactory.createGetTimeRequestsRequest(request));
        return response.getValue();
    }

    @Override
    public PutTimeClockEventsResponseType putTimeClockEvents(PutTimeClockEventsRequestType request) {
        JAXBElement<PutTimeClockEventsResponseType> response = send(
                objectFactory.createPutTimeClockEventsRequest(request));
        return response.getValue();
    }

    @SuppressWarnings("unchecked")
    private <T> JAXBElement<T> send(JAXBElement<?> request) {
        return (JAXBElement<T>) webServiceTemplate.marshalSendAndReceive(
                properties.getEndpointUrl(),
                request);
    }
}
