package com.example.timetracking.service;

import com.example.timetracking.config.TimeTrackingSoapProperties;
import com.example.timetracking.config.MaskingCxfLogEventSender;
import com.example.timetracking.workday.AuthenticationFaultMsg;
import com.example.timetracking.workday.GetTimeRequestsRequestType;
import com.example.timetracking.workday.GetTimeRequestsResponseType;
import com.example.timetracking.workday.ProcessingFaultMsg;
import com.example.timetracking.workday.PutTimeClockEventsRequestType;
import com.example.timetracking.workday.PutTimeClockEventsResponseType;
import com.example.timetracking.workday.TimeTrackingPort;
import com.example.timetracking.workday.TimeTrackingService;
import com.example.timetracking.workday.ValidationFaultMsg;
import java.util.HashMap;
import java.util.Map;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.xml.ws.BindingProvider;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.ext.logging.LoggingInInterceptor;
import org.apache.cxf.ext.logging.LoggingOutInterceptor;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.wss4j.common.ext.WSPasswordCallback;
import org.apache.wss4j.dom.WSConstants;
import org.apache.wss4j.dom.handler.WSHandlerConstants;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

@Service
public class CxfTimeTrackingClient implements TimeTrackingOperations {

    private final TimeTrackingPort port;

    public CxfTimeTrackingClient(TimeTrackingSoapProperties properties) {
        this.port = createPort(properties);
    }

    @Override
    public GetTimeRequestsResponseType getTimeRequests(GetTimeRequestsRequestType request) {
        try {
            return port.getTimeRequests(request);
        } catch (ValidationFaultMsg | ProcessingFaultMsg | AuthenticationFaultMsg ex) {
            throw new TimeTrackingSoapException("Get_Time_Requests failed", ex);
        }
    }

    @Override
    public PutTimeClockEventsResponseType putTimeClockEvents(PutTimeClockEventsRequestType request) {
        try {
            return port.putTimeClockEvents(request);
        } catch (ValidationFaultMsg | ProcessingFaultMsg | AuthenticationFaultMsg ex) {
            throw new TimeTrackingSoapException("Put_Time_Clock_Events failed", ex);
        }
    }

    private TimeTrackingPort createPort(TimeTrackingSoapProperties properties) {
        try {
            ClassPathResource wsdl = new ClassPathResource("wsdl/Time_Tracking.wsdl");
            TimeTrackingService service = new TimeTrackingService(wsdl.getURL());
            TimeTrackingPort timeTrackingPort = service.getTimeTracking();
            ((BindingProvider) timeTrackingPort).getRequestContext()
                    .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, properties.getEndpointUrl());
            Client client = ClientProxy.getClient(timeTrackingPort);
            addLoggingInterceptors(client, properties);
            client.getOutInterceptors().add(usernameTokenInterceptor(properties));
            return timeTrackingPort;
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to create CXF Time Tracking SOAP client", ex);
        }
    }

    private void addLoggingInterceptors(Client client, TimeTrackingSoapProperties properties) {
        if (!properties.isLogMessages()) {
            return;
        }

        MaskingCxfLogEventSender logEventSender = new MaskingCxfLogEventSender();

        LoggingOutInterceptor outInterceptor = new LoggingOutInterceptor(logEventSender);
        outInterceptor.setPrettyLogging(true);
        outInterceptor.setLimit(properties.getLogPayloadMaxChars());

        LoggingInInterceptor inInterceptor = new LoggingInInterceptor(logEventSender);
        inInterceptor.setPrettyLogging(true);
        inInterceptor.setLimit(properties.getLogPayloadMaxChars());

        client.getOutInterceptors().add(outInterceptor);
        client.getInInterceptors().add(inInterceptor);
    }

    private WSS4JOutInterceptor usernameTokenInterceptor(TimeTrackingSoapProperties properties) {
        Map<String, Object> outProperties = new HashMap<>();
        outProperties.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
        outProperties.put(WSHandlerConstants.USER, properties.getUsername());
        outProperties.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
        outProperties.put(WSHandlerConstants.PW_CALLBACK_REF, usernameTokenPassword(properties.getPassword()));
        return new WSS4JOutInterceptor(outProperties);
    }

    private CallbackHandler usernameTokenPassword(String password) {
        return callbacks -> {
            for (Callback callback : callbacks) {
                if (callback instanceof WSPasswordCallback) {
                    WSPasswordCallback passwordCallback = (WSPasswordCallback) callback;
                    passwordCallback.setPassword(password);
                    continue;
                }
                throw new UnsupportedCallbackException(callback);
            }
        };
    }
}
