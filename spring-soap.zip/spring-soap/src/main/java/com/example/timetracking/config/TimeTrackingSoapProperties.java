package com.example.timetracking.config;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "time-tracking.soap")
public class TimeTrackingSoapProperties {

    private String endpointUrl;
    private String username;
    private String password;
    private Duration connectTimeout = Duration.ofSeconds(10);
    private Duration readTimeout = Duration.ofSeconds(60);
    private boolean logMessages = true;
    private int logPayloadMaxChars = 20000;

    public TimeTrackingSoapProperties() {
    }

    public TimeTrackingSoapProperties(
            String endpointUrl,
            String username,
            String password,
            Duration connectTimeout,
            Duration readTimeout) {
        this.endpointUrl = endpointUrl;
        this.username = username;
        this.password = password;
        this.connectTimeout = connectTimeout;
        this.readTimeout = readTimeout;
    }

    public String getEndpointUrl() {
        return endpointUrl;
    }

    public void setEndpointUrl(String endpointUrl) {
        this.endpointUrl = endpointUrl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Duration getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(Duration connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public Duration getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(Duration readTimeout) {
        this.readTimeout = readTimeout;
    }

    public boolean isLogMessages() {
        return logMessages;
    }

    public void setLogMessages(boolean logMessages) {
        this.logMessages = logMessages;
    }

    public int getLogPayloadMaxChars() {
        return logPayloadMaxChars;
    }

    public void setLogPayloadMaxChars(int logPayloadMaxChars) {
        this.logPayloadMaxChars = logPayloadMaxChars;
    }
}
