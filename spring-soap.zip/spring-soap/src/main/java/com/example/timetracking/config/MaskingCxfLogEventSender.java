package com.example.timetracking.config;

import org.apache.cxf.ext.logging.event.LogEvent;
import org.apache.cxf.ext.logging.slf4j.Slf4jEventSender;

public class MaskingCxfLogEventSender extends Slf4jEventSender {

    private static final String PASSWORD_MASK = "$1***$3";

    @Override
    public void send(LogEvent event) {
        event.setPayload(maskSecrets(event.getPayload()));
        super.send(event);
    }

    private String maskSecrets(String payload) {
        if (payload == null) {
            return null;
        }
        return payload.replaceAll("(<[^>]*Password[^>]*>)(.*?)(</[^>]*Password>)", PASSWORD_MASK);
    }
}
