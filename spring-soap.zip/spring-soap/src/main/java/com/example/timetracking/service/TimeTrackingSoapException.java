package com.example.timetracking.service;

public class TimeTrackingSoapException extends RuntimeException {

    public TimeTrackingSoapException(String message, Throwable cause) {
        super(message, cause);
    }
}
