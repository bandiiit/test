package com.example.timetracking.service;

import com.example.timetracking.workday.GetTimeRequestsRequestType;
import com.example.timetracking.workday.GetTimeRequestsResponseType;
import com.example.timetracking.workday.PutTimeClockEventsRequestType;
import com.example.timetracking.workday.PutTimeClockEventsResponseType;

public interface TimeTrackingOperations {

    GetTimeRequestsResponseType getTimeRequests(GetTimeRequestsRequestType request);

    PutTimeClockEventsResponseType putTimeClockEvents(PutTimeClockEventsRequestType request);
}
