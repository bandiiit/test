package com.example.timetracking.config;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;

@Component
public class TimeTrackingSoapLoggingInterceptor implements ClientInterceptor {

    private static final Logger log = LoggerFactory.getLogger(TimeTrackingSoapLoggingInterceptor.class);
    private static final String PASSWORD_MASK = "$1***$3";

    private final TimeTrackingSoapProperties properties;

    public TimeTrackingSoapLoggingInterceptor(TimeTrackingSoapProperties properties) {
        this.properties = properties;
    }

    @Override
    public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
        logMessage("SOAP request", messageContext.getRequest());
        return true;
    }

    @Override
    public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
        logMessage("SOAP response", messageContext.getResponse());
        return true;
    }

    @Override
    public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
        logMessage("SOAP fault", messageContext.getResponse());
        return true;
    }

    @Override
    public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {
        if (ex != null && properties.isLogMessages()) {
            log.warn("SOAP exchange completed with exception", ex);
        }
    }

    private void logMessage(String label, WebServiceMessage message) {
        if (!properties.isLogMessages() || message == null) {
            return;
        }

        try {
            String payload = serialize(message);
            log.info("{}:\n{}", label, truncate(maskSecrets(payload)));
        } catch (IOException ex) {
            log.warn("Unable to log {}", label, ex);
        }
    }

    private String serialize(WebServiceMessage message) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        message.writeTo(output);
        return output.toString(StandardCharsets.UTF_8.name());
    }

    private String maskSecrets(String payload) {
        return payload.replaceAll("(<[^>]*Password[^>]*>)(.*?)(</[^>]*Password>)", PASSWORD_MASK);
    }

    private String truncate(String payload) {
        int maxChars = properties.getLogPayloadMaxChars();
        if (maxChars <= 0 || payload.length() <= maxChars) {
            return payload;
        }
        return payload.substring(0, maxChars) + "...[truncated]";
    }
}
