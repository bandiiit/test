import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import java.text.SimpleDateFormat;
import java.util.*;

public class ReportApp {

    // === POJO（字段名需和 subDataset 的 <field name="..."> 对齐）===
    public static class InboundRow {
        public String poNo, supplier, warehouse, status;
        public Date eta;
        public Integer receivedQty;
        public InboundRow(String poNo, String supplier, String warehouse, Date eta, Integer receivedQty, String status) {
            this.poNo = poNo; this.supplier = supplier; this.warehouse = warehouse;
            this.eta = eta; this.receivedQty = receivedQty; this.status = status;
        }
    }

    public static class OutboundRow {
        public String soNo, customer, warehouse, carrier;
        public Date shipDate;
        public Integer shippedQty;
        public OutboundRow(String soNo, String customer, String warehouse, Date shipDate, Integer shippedQty, String carrier) {
            this.soNo = soNo; this.customer = customer; this.warehouse = warehouse;
            this.shipDate = shipDate; this.shippedQty = shippedQty; this.carrier = carrier;
        }
    }

    public static void main(String[] args) throws Exception {
        JasperReport jasper = JasperCompileManager.compileReport("example-report.jrxml");

        // === 准备对象数据 ===
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<InboundRow> inbound = Arrays.asList(
            new InboundRow("PO-1001","Acme Components","Edison",sdf.parse("2025-09-02"),120,"RECEIVED"),
            new InboundRow("PO-1002","Acme Components","Selena",sdf.parse("2025-09-05"),80,"PARTIAL"),
            new InboundRow("PO-1003","Bravo Metals","Edison",sdf.parse("2025-09-09"),200,"RECEIVED"),
            new InboundRow("PO-1004","Delta Plastics","Selena",sdf.parse("2025-09-12"),0,"WAITING"),
            new InboundRow("PO-1005","Bravo Metals","Edison",sdf.parse("2025-09-18"),150,"RECEIVED")
        );

        List<OutboundRow> outbound = Arrays.asList(
            new OutboundRow("SO-9001","Zenith Retail","Edison",sdf.parse("2025-09-03"),60,"UPS"),
            new OutboundRow("SO-9002","Northwind LLC","Selena",sdf.parse("2025-09-06"),45,"FEDEX"),
            new OutboundRow("SO-9003","Zenith Retail","Edison",sdf.parse("2025-09-10"),120,"DHL"),
            new OutboundRow("SO-9004","Orion Stores","Selena",sdf.parse("2025-09-15"),30,"UPS"),
            new OutboundRow("SO-9005","Helios Mart","Edison",sdf.parse("2025-09-20"),95,"FEDEX")
        );

        // === 以参数形式把两个数据源喂给表格 ===
        Map<String, Object> params = new HashMap<>();
        params.put("INBOUND_DS",  new JRBeanCollectionDataSource(inbound));
        params.put("OUTBOUND_DS", new JRBeanCollectionDataSource(outbound));

        // 其他展示参数（若你 JRXML 有）
        params.put("pReportTitle", "Monthly Warehouse Operations Summary");
        params.put("pMonth", "2025-09");

        // 主报表用空数据源（所有数据都从参数传给 jr:table）
        JasperPrint jp = JasperFillManager.fillReport(jasper, params, new JREmptyDataSource());

        JasperExportManager.exportReportToPdfFile(jp, "warehouse-summary.pdf");
    }
}
