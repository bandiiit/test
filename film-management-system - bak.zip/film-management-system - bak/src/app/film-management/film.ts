import { Category } from './enums/category.enum';
import { Country } from './enums/country.enum';
import { Language } from './enums/language.enum';
import { SelectOption } from './enums/select-option';

export interface Film {
    id: number; 
    title: string;
    director: string;
    releaseDate: Date; 
    description: string;
    category: SelectOption;
    country: SelectOption;
    language: SelectOption;
    creator: string;
    create: Date;
    lastUpdator: string;
    lastUpdate: Date;
    // ... any other existing fields ...
}