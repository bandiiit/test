export enum Country {
    USA = 'USA',
    UK = 'UK',
    FRANCE = 'FRANCE',
    // ... other countries
}