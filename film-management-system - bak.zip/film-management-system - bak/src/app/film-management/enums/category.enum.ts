export enum Category {
    ACTION = 'ACTION',
    DRAMA = 'DRAMA',
    COMEDY = 'COMEDY',
    // ... other categories
}