export interface SelectOption {
    id: number;
    key: string; // for internal usage/storing
    value: string; // for display
}