import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Film } from './film'
import { SelectOption } from './enums/select-option';
import { PaginatedResult } from './enums/paginated-result';

@Injectable({
  providedIn: 'root'
})
export class FilmService {

  private films: Film[] = [];
  private nextId: number = 21; // Since you initialized 20 films, we start from 21

  constructor() { 
    this.initializeData();
  }

  private initializeData(): void {
    const categories: SelectOption[] = [
      { id: 1, key: 'ACTION', value: 'Action' },
      { id: 2, key: 'DRAMA', value: 'Drama' },
      // ... you can add more categories
    ];

    const countries: SelectOption[] = [
      { id: 1, key: 'USA', value: 'USA' },
      { id: 2, key: 'UK', value: 'UK' },
      // ... more countries
    ];

    const languages: SelectOption[] = [
      { id: 1, key: 'ENGLISH', value: 'English' },
      { id: 2, key: 'SPANISH', value: 'Spanish' },
      // ... more languages
    ];

    for (let i = 0; i < 20; i++) {
      const film: Film = {
        id: i, // Adding the 'id' field
        title: `Title ${i}`, // Adding a dummy 'title'
        director: `Director ${i}`, // Adding a dummy 'director'
        releaseDate: new Date(), // You can randomize this as needed
        // ... other existing fields ...
        category: categories[Math.floor(Math.random() * categories.length)],
        country: countries[Math.floor(Math.random() * countries.length)],
        language: languages[Math.floor(Math.random() * languages.length)],
        description: `This is a sample description for film ${i}`,
        creator: 'System',
        create: new Date(), // This sets the creation date to now
        lastUpdator: 'System',
        lastUpdate: new Date(), // This sets the last update date to now
      };
      this.films.push(film);
    }
  }

  getFilms(params: { page: number, pageSize: number, /* other filters */ }): Observable<PaginatedResult<Film>> {
    // ... obtain full list or filtered list based on other parameters ...
  
    // now, slice the array based on the pagination parameters
    const result = new PaginatedResult<Film>();
    result.items = this.films.slice(params.page * params.pageSize, (params.page + 1) * params.pageSize);
    result.total = this.films.length;
  
    return of(result);
  }

  searchFilms(filters: any): Observable<PaginatedResult<Film>> {
    // Filtering logic here, you can adjust as needed for your actual model
    let results = this.films; // this.films refers to your local data
  
    if (filters.title) {
      results = results.filter(film => film.title.toLowerCase().includes(filters.title.toLowerCase()));
    }
  
    if (filters.director) {
      results = results.filter(film => film.director.toLowerCase().includes(filters.director.toLowerCase()));
    }
  
    // ... similar checks for other string fields ...
  
    if (filters.releaseDateStart && filters.releaseDateEnd) {
      const startDate = new Date(filters.releaseDateStart);
      const endDate = new Date(filters.releaseDateEnd);
  
      results = results.filter(film => {
        const releaseDate = new Date(film.releaseDate);
        return releaseDate >= startDate && releaseDate <= endDate;
      });
    }
  
    // For category, country, language, since you're dealing with select options
    if (filters.category) {
      results = results.filter(film => film.category.id === filters.category);
    }
  
    // ... similar checks for country and language ...
  
    // Return the filtered results as an Observable
    let pageResult = new PaginatedResult<Film>();
    pageResult.total = results.length;
    pageResult.items = results;
    return of(pageResult);
  }

  getFilm(id: number): Observable<Film | undefined> {
    const film = this.films.find(f => f.id === id);
    return of(film); // Simulate a network request/response cycle
  }

  addFilm(film: Film): Observable<Film> {
    // You would normally handle IDs on the server. Here, we manually increment.
    const newFilm = {
      ...film,
      id: this.nextId++
    };
    this.films.push(newFilm);
    return of(newFilm);
  }

  updateFilm(updatedFilm: Film): Observable<Film> {
    const index = this.films.findIndex(f => f.id === updatedFilm.id);
    if (index === -1) {
      // handle error, e.g., throw an error or return an appropriate response
    } else {
      this.films[index] = updatedFilm;
    }
    return of(updatedFilm); // Simulate server response
  }

  deleteFilm(id: number): Observable<{}> {
    const index = this.films.findIndex(f => f.id === id);
    if (index === -1) {
      // handle error, e.g., throw an error or return an appropriate response
    } else {
      this.films.splice(index, 1);
    }
    return of({}); // Simulating a server response, usually empty for deletions.
  }
}
