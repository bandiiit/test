import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FilmListComponent } from './film-list/film-list.component';
import { FilmDetailComponent } from './film-detail/film-detail.component';
import { FilmEditComponent } from './film-edit/film-edit.component';
import { FilmAddComponent } from './film-add/film-add.component';

const routes: Routes = [
  { path: '', component: FilmListComponent },
  { path: 'detail/:id', component: FilmDetailComponent },
  { path: 'edit/:id', component: FilmEditComponent },
  { path: 'add', component: FilmAddComponent }
  // ... any other routes ...
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FilmManagementRoutingModule { }
