import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FilmService } from '../film.service';
import { Film } from '../film';
import { PageEvent } from '@angular/material/paginator';
import { Category } from '../enums/category.enum';



@Component({
  selector: 'app-film-list',
  templateUrl: './film-list.component.html',
  styleUrls: ['./film-list.component.css'],
})
export class FilmListComponent implements OnInit {

  searchForm!: FormGroup;
  films: Film[] = [];
  displayedColumns: string[] = ['title', 'actions'];
  
  // Pagination
  totalItems = 0;
  itemsPerPage = 10; // for example
  pageSizeOptions: number[] = [5, 10, 25, 100]; // example options

  currentPage = 1;
  pageSize = 10;

  // This would ideally come from a service that holds your select options
  categories = [{id: 1, key: Category.ACTION, value: 'Action'}, {id: 2, key: Category.COMEDY, value: 'Comedy'}, {id: 3, key: Category.DRAMA, value: 'Drama'}]; // Populate with real data
  countries = []; // Populate with real data
  languages = []; // Populate with real data

  constructor(private fb: FormBuilder, 
    private filmService: FilmService) { }

  ngOnInit(): void {
    this.searchForm = this.fb.group({
      title: [''],
      director: [''],
      description: [''],
      category: [null],
      country: [null],
      language: [null],
      releaseDateStart: [null],
      releaseDateEnd: [null],
      // ... other fields as necessary
    });
    this.loadPage();
  }

  onSearch(): void {
    const filters = this.searchForm.value;
    // Here, call the method from the service to perform the search
    this.filmService.searchFilms(filters).subscribe(results => {
      // this.films = results;
      this.loadPage();
    });
  }

  editFilm(id: number) {
    // Here you would typically handle navigation to an edit component or open a dialog with the film's details.
  }
  
  deleteFilm(id: number) {
    this.filmService.deleteFilm(id).subscribe(() => {
      // On success, you might want to remove the film from the local array, for instance,
      // to prevent the need for a new request for the entire list.
      // this.films = this.films.filter(film => film.id !== id);
      this.loadPage();
    });
  }

  loadPage() {
    const pageIndex = 1/* obtain current page index from paginator or state */;
    
    this.filmService.getFilms({
      page: pageIndex,
      pageSize: this.itemsPerPage,
      // other filters
    }).subscribe(paginatedFilms => {
      this.films = paginatedFilms.items; // Adjust based on your actual pagination model
      this.totalItems = paginatedFilms.total; // Total items count from the response
    });
  }
  
  pageChanged(event: PageEvent) {
    this.itemsPerPage = event.pageSize;
    this.loadPage();
  }

  onEdit(film: Film): void {
    if (film.title.includes('10')) {
      // if the title contains '10', do not proceed with the edit action
      return;
    }
  
    // ... rest of your edit logic
  }
}
