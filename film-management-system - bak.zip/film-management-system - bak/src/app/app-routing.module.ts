import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';

// Import your components here
// import { HomeComponent } from './home/home.component';
// import { MoviesComponent } from './movies/movies.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' }, // Redirects to /home by default
  { path: 'home', component: HomeComponent }, // Home route
  { path: 'film', loadChildren: () => import('./film-management/film-management.module').then(m => m.FilmManagementModule) }
  // You can add more routes here later on
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
